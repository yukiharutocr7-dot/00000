# Third-party notices

Verify every license below yourself before redistributing. Nothing listed under "Runtime components" is bundled in this repository or in the APK.

## Libraries linked into the app (Maven Central / Google Maven)

| Component | License | Source |
|---|---|---|
| Jetpack Compose, AndroidX (core, activity, lifecycle, navigation, room, documentfile) | Apache-2.0 | https://developer.android.com/jetpack |
| Kotlin and kotlinx.coroutines | Apache-2.0 | https://github.com/JetBrains/kotlin |
| Apache Commons Compress | Apache-2.0 | https://commons.apache.org/proper/commons-compress/ |
| XZ for Java | Public domain | https://tukaani.org/xz/java.html |

## Runtime components (NOT bundled; downloaded only if the user configures a manifest)

| Component | Typical license | Source |
|---|---|---|
| Wine | LGPL-2.1-or-later | https://gitlab.winehq.org/wine/wine |
| Box64 | MIT | https://github.com/ptitSeb/box64 |
| PRoot | GPL-2.0-or-later | https://github.com/proot-me/proot |
| DXVK | zlib/libpng | https://github.com/doitsujin/dxvk |
| VKD3D-Proton | LGPL-2.1-or-later | https://github.com/HansKristian-Work/vkd3d-proton |
| Mesa / Turnip / Zink | MIT | https://www.mesa3d.org |

If you redistribute binaries of GPL or LGPL components you must also provide their corresponding source and license texts. Do not bundle Microsoft files or other proprietary Windows components.

## Reference projects (studied for architecture; no code copied)

- Winlator (https://github.com/brunodev85/winlator): reference for running Wine on Android using proot, Box64 and a custom X server. Check its license and the license of any fork before reusing code.

## Build tooling

- mingw-w64 (used only in CI to compile the test programs in testapp/). The produced executables are original code written for this project.

## Project license

No license file is included yet. Add one (for example MIT or Apache-2.0) before publishing the repository.
