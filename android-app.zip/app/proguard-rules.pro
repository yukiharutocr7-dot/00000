# PocketWin: release minification is disabled. Keep JNI entry points if it is ever enabled.
-keepclasseswithmembernames class * {
    native <methods>;
}
