package com.pocketwin.input

import org.junit.Assert.assertEquals
import org.junit.Test

class TouchMouseMapperTest {
    private fun capture(block: (TouchMouseMapper) -> Unit): List<MouseEvent> {
        val out = ArrayList<MouseEvent>()
        block(TouchMouseMapper { out.add(it) })
        return out
    }

    @Test
    fun tapIsLeftClick() {
        assertEquals(
            listOf(MouseEvent.Button(MouseButton.LEFT, true), MouseEvent.Button(MouseButton.LEFT, false)),
            capture { it.tap() }
        )
    }

    @Test
    fun longPressIsRightClick() {
        assertEquals(
            listOf(MouseEvent.Button(MouseButton.RIGHT, true), MouseEvent.Button(MouseButton.RIGHT, false)),
            capture { it.longPress() }
        )
    }

    @Test
    fun oneFingerMovesTwoFingersScroll() {
        assertEquals(listOf<MouseEvent>(MouseEvent.Move(3f, 4f)), capture { it.drag(3f, 4f, 1) })
        assertEquals(listOf<MouseEvent>(MouseEvent.Scroll(4f)), capture { it.drag(3f, 4f, 2) })
    }
}
