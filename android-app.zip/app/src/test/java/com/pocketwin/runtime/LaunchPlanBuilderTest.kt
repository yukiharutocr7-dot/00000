package com.pocketwin.runtime

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files

class LaunchPlanBuilderTest {
    private fun rt(root: File) = ResolvedRuntime(
        File(root, "rootfs").also { it.mkdirs() },
        File(root, "proot"),
        null,
        null,
        "/usr/local/bin/box64",
        "/opt/wine/bin/wine64"
    )

    @Test
    fun buildsProotBox64WineCommand() {
        val root = Files.createTempDirectory("pwtest").toFile()
        val plan = LaunchPlanBuilder.build(
            rt = rt(root),
            prefixDir = File(root, "prefix"),
            containerTmp = File(root, "ctmp"),
            prootTmp = File(root, "ptmp"),
            programDir = File(root, "prog"),
            cwdGuest = "/pocketwin/program",
            wineArgv = listOf("/pocketwin/program/a b.exe", "--x"),
            userEnv = mapOf("WINEDEBUG" to "err+all", "FOO" to "bar"),
            display = null,
            logFile = File(root, "log.txt")
        )
        val a = plan.argv
        assertEquals(File(root, "proot").absolutePath, a[0])
        assertTrue(a.contains("${File(root, "prefix").absolutePath}:/pocketwin/prefix"))
        assertTrue(a.contains("${File(root, "prog").absolutePath}:/pocketwin/program"))
        val tail = a.takeLast(4)
        assertEquals(listOf("/usr/local/bin/box64", "/opt/wine/bin/wine64", "/pocketwin/program/a b.exe", "--x"), tail)
        assertTrue(plan.env.contains("WINEDEBUG=err+all"))
        assertTrue(plan.env.contains("FOO=bar"))
        assertTrue(plan.env.contains("WINEPREFIX=/pocketwin/prefix"))
        assertTrue(plan.env.none { it.startsWith("DISPLAY=") })
        assertTrue(plan.env.any { it.startsWith("PROOT_TMP_DIR=") })
    }

    @Test
    fun setsDisplayWhenProvided() {
        val root = Files.createTempDirectory("pwtest").toFile()
        val plan = LaunchPlanBuilder.build(
            rt(root), File(root, "p"), File(root, "t"), File(root, "pt"), null,
            "/pocketwin/prefix", listOf("wineboot", "-u"), emptyMap(), ":0", File(root, "l")
        )
        assertTrue(plan.env.contains("DISPLAY=:0"))
        assertTrue(plan.argv.none { it.endsWith(":/pocketwin/program") })
    }
}
