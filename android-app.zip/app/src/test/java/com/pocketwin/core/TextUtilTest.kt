package com.pocketwin.core

import org.junit.Assert.assertEquals
import org.junit.Test

class TextUtilTest {
    @Test
    fun splitsQuotedArguments() {
        assertEquals(listOf("--a", "b c", "d e", "f"), TextUtil.splitArgs("--a \"b c\" 'd e' f"))
        assertEquals(emptyList<String>(), TextUtil.splitArgs("   "))
        assertEquals(listOf(""), TextUtil.splitArgs("\"\""))
    }

    @Test
    fun parsesEnvLines() {
        val m = TextUtil.parseEnv("# c\nA=1\n  B = two words \nbad key=3\n=x\nC=\n")
        assertEquals(mapOf("A" to "1", "B" to "two words", "C" to ""), m)
    }

    @Test
    fun sanitizesNamesButKeepsArabic() {
        assertEquals("a_b", TextUtil.sanitizeName("a/b"))
        assertEquals("برنامج.exe", TextUtil.sanitizeName("برنامج.exe"))
        assertEquals("file", TextUtil.sanitizeName(".."))
    }

    @Test
    fun convertsUnixPathToWindowsPath() {
        assertEquals("Z:\\pocketwin\\program\\a b.msi", TextUtil.windowsPathForUnix("/pocketwin/program/a b.msi"))
    }
}
