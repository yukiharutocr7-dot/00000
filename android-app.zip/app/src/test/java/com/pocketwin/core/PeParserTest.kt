package com.pocketwin.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PeParserTest {
    private fun makePe(machine: Int, subsystem: Int, characteristics: Int = 0x0022, pe32Plus: Boolean = true, clr: Boolean = false): ByteArray {
        val b = ByteArray(1024)
        b[0] = 'M'.code.toByte()
        b[1] = 'Z'.code.toByte()
        b[0x3C] = 0x80.toByte()
        val pe = 0x80
        b[pe] = 'P'.code.toByte()
        b[pe + 1] = 'E'.code.toByte()
        b[pe + 4] = (machine and 0xFF).toByte()
        b[pe + 5] = ((machine shr 8) and 0xFF).toByte()
        b[pe + 22] = (characteristics and 0xFF).toByte()
        b[pe + 23] = ((characteristics shr 8) and 0xFF).toByte()
        val opt = pe + 24
        val magic = if (pe32Plus) 0x20B else 0x10B
        b[opt] = (magic and 0xFF).toByte()
        b[opt + 1] = ((magic shr 8) and 0xFF).toByte()
        b[opt + 68] = subsystem.toByte()
        val countOff = opt + if (pe32Plus) 108 else 92
        val dirBase = opt + if (pe32Plus) 112 else 96
        b[countOff] = 16
        if (clr) {
            b[dirBase + 14 * 8] = 0x00
            b[dirBase + 14 * 8 + 1] = 0x20
            b[dirBase + 14 * 8 + 4] = 0x48
        }
        return b
    }

    @Test
    fun parsesX64Gui() {
        val i = PeParser.parse(makePe(0x8664, 2))
        assertEquals(FileKind.PE, i.kind)
        assertEquals(PeArch.X64, i.arch)
        assertEquals(true, i.isGui)
        assertFalse(i.isDll)
        assertFalse(i.isDotNet)
    }

    @Test
    fun parsesX86Console() {
        val i = PeParser.parse(makePe(0x014C, 3, pe32Plus = false))
        assertEquals(PeArch.X86, i.arch)
        assertEquals(false, i.isGui)
    }

    @Test
    fun parsesArm64AndDllAndDotNet() {
        val i = PeParser.parse(makePe(0xAA64, 2, characteristics = 0x2022, clr = true))
        assertEquals(PeArch.ARM64, i.arch)
        assertTrue(i.isDll)
        assertTrue(i.isDotNet)
    }

    @Test
    fun rejectsNonPe() {
        assertEquals(PeArch.NOT_PE, PeParser.parse(ByteArray(10)).arch)
        assertEquals(PeArch.NOT_PE, PeParser.parse("hello world, this is text".repeat(8).toByteArray()).arch)
    }

    @Test
    fun rejectsTruncatedHeader() {
        val b = makePe(0x8664, 2).copyOf(0x84)
        assertEquals(PeArch.NOT_PE, PeParser.parse(b).arch)
    }

    @Test
    fun detectsMsiContainer() {
        val b = ByteArray(512)
        intArrayOf(0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1).forEachIndexed { i, v -> b[i] = v.toByte() }
        assertEquals(FileKind.OLE_COMPOUND, PeParser.parse(b).kind)
    }
}
