package com.pocketwin.program

import com.pocketwin.container.ContainerManager
import com.pocketwin.core.AppPaths
import com.pocketwin.core.CompatState
import com.pocketwin.core.FileUtil
import com.pocketwin.core.OpResult
import com.pocketwin.core.OpStatus
import com.pocketwin.core.PeArch
import com.pocketwin.core.ProgramKind
import com.pocketwin.core.ProgramLocation
import com.pocketwin.core.SettingsStore
import com.pocketwin.core.TextUtil
import com.pocketwin.data.ProgramDao
import com.pocketwin.data.ProgramEntity
import com.pocketwin.diagnostics.PwLog
import com.pocketwin.process.RuntimeProcessManager
import com.pocketwin.runtime.LaunchPlanBuilder
import com.pocketwin.runtime.RuntimeManager
import com.pocketwin.session.DisplayBackend
import com.pocketwin.session.SessionPhase
import com.pocketwin.session.SessionState
import com.pocketwin.session.WindowSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class ProgramRunner(
    private val paths: AppPaths,
    private val dao: ProgramDao,
    private val containers: ContainerManager,
    private val runtime: RuntimeManager,
    private val processes: RuntimeProcessManager,
    private val sessions: WindowSessionManager,
    private val display: DisplayBackend,
    private val settings: SettingsStore,
    private val scope: CoroutineScope
) {
    private val stopRequested = ConcurrentHashMap.newKeySet<String>()

    suspend fun installProgram(id: String): OpResult<Unit> = launchInternal(id, true)

    suspend fun launchProgram(id: String): OpResult<Unit> = launchInternal(id, false)

    private fun fail(id: String, status: OpStatus, msg: String): OpResult<Unit> {
        sessions.update(SessionState(id, SessionPhase.FAILED, msg))
        PwLog.w("Runner", "$id: $msg")
        return OpResult(status, msg)
    }

    private suspend fun launchInternal(id: String, installerMode: Boolean): OpResult<Unit> = withContext(Dispatchers.IO) {
        val p = dao.get(id) ?: return@withContext OpResult.failed<Unit>("Program not found")
        if (processes.isRunning(id)) return@withContext OpResult.failed<Unit>("Program is already running")
        val arch = runCatching { PeArch.valueOf(p.arch) }.getOrDefault(PeArch.UNKNOWN)
        if (arch == PeArch.ARM64 || arch == PeArch.ARM) {
            return@withContext fail(id, OpStatus.FAILED, "ARM Windows binaries cannot run on the x86-64 emulation chain")
        }
        if (!p.trusted) return@withContext fail(id, OpStatus.NOT_READY, "TRUST_REQUIRED")
        val (rt, missing) = runtime.resolve()
        if (rt == null) {
            return@withContext fail(id, OpStatus.NOT_READY, "Runtime not ready: " + missing.joinToString("; "))
        }
        val headless = settings.state.value.allowHeadless
        if (!display.available && !headless) {
            return@withContext fail(
                id, OpStatus.NOT_IMPLEMENTED,
                "Display backend not implemented (${display.unavailableReason}). Enable headless launch in Settings to run console programs."
            )
        }
        val container = containers.get(p.containerId)
            ?: return@withContext fail(id, OpStatus.FAILED, "The container of this program no longer exists")

        sessions.update(SessionState(id, SessionPhase.PREPARING, "Preparing container ${container.name}"))
        val init = containers.ensureInitialized(container.id) { msg ->
            sessions.update(SessionState(id, SessionPhase.PREPARING, msg))
        }
        if (!init.ok) return@withContext fail(id, init.status, init.message)

        val imported = p.location == ProgramLocation.IMPORTED.name
        val guestBase = if (imported) LaunchPlanBuilder.GUEST_PROGRAM else LaunchPlanBuilder.GUEST_PREFIX
        val guestExe = "$guestBase/${p.exeRelPath}"
        val cwdGuest = guestExe.substringBeforeLast('/')
        val wineArgs = ArrayList<String>()
        if (p.kind == ProgramKind.MSI.name) {
            wineArgs.addAll(listOf("msiexec", "/i", TextUtil.windowsPathForUnix(guestExe)))
        } else {
            wineArgs.add(guestExe)
        }
        wineArgs.addAll(TextUtil.splitArgs(p.args))

        val log = paths.programLog(id)
        log.parentFile?.mkdirs()
        log.appendText("--- ${if (installerMode) "installer" else "launch"} ${java.util.Date()} ---\n")
        val plan = LaunchPlanBuilder.build(
            rt = rt,
            prefixDir = paths.prefixDir(container.id),
            containerTmp = paths.containerTmp(container.id),
            prootTmp = File(paths.tmp, "proot"),
            programDir = if (imported) File(p.baseDir) else null,
            cwdGuest = cwdGuest,
            wineArgv = wineArgs,
            userEnv = TextUtil.parseEnv(p.envVars),
            display = display.displayEnv(),
            logFile = log
        )
        stopRequested.remove(id)
        val started = processes.start(id, plan) { code -> onExit(id, code) }
        if (!started.ok) return@withContext fail(id, started.status, started.message)
        sessions.update(
            SessionState(id, SessionPhase.RUNNING, if (installerMode) "Installer running" else "Running", pid = started.value ?: -1)
        )
        dao.upsert(p.copy(lastRunAt = System.currentTimeMillis(), lastResult = "RUNNING"))
        OpResult.success(Unit, "Started")
    }

    private fun onExit(id: String, code: Int) {
        val requested = stopRequested.remove(id)
        val phase = if (requested || code == 0) SessionPhase.EXITED else SessionPhase.CRASHED
        sessions.update(SessionState(id, phase, if (phase == SessionPhase.EXITED) "Exited" else "Exited with an error", exitCode = code))
        scope.launch {
            val cur = dao.get(id) ?: return@launch
            val compat = when {
                requested -> cur.compat
                code == 0 -> CompatState.RAN_OK.name
                else -> CompatState.FAILED.name
            }
            dao.upsert(cur.copy(lastRunAt = System.currentTimeMillis(), lastResult = "exit=$code", compat = compat))
        }
    }

    suspend fun stopProgram(id: String): OpResult<Unit> {
        if (!processes.isRunning(id)) return OpResult.success(Unit, "Not running")
        stopRequested.add(id)
        val gone = processes.stop(id)
        return if (gone) OpResult.success(Unit, "Stopped") else OpResult.failed("Process did not stop")
    }

    suspend fun restartProgram(id: String): OpResult<Unit> {
        stopProgram(id)
        return launchProgram(id)
    }

    fun getProgramStatus(id: String): SessionState = sessions.get(id)

    fun getProgramLogs(id: String, maxBytes: Int = 16384): String =
        PwLog.tail(paths.programLog(id), maxBytes)

    suspend fun deleteProgram(id: String): OpResult<Unit> = withContext(Dispatchers.IO) {
        val p = dao.get(id) ?: return@withContext OpResult.failed<Unit>("Program not found")
        if (processes.isRunning(id)) stopProgram(id)
        if (p.location == ProgramLocation.IMPORTED.name) FileUtil.deleteTree(File(p.baseDir))
        paths.programLog(id).delete()
        dao.delete(id)
        OpResult.success(Unit, "Deleted")
    }
}
