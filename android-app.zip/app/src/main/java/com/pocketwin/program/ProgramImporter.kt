package com.pocketwin.program

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.pocketwin.core.AppPaths
import com.pocketwin.core.CompatState
import com.pocketwin.core.FileKind
import com.pocketwin.core.FileUtil
import com.pocketwin.core.OpResult
import com.pocketwin.core.PeArch
import com.pocketwin.core.PeInfo
import com.pocketwin.core.PeParser
import com.pocketwin.core.ProgramKind
import com.pocketwin.core.ProgramLocation
import com.pocketwin.core.SettingsStore
import com.pocketwin.core.TextUtil
import com.pocketwin.data.ProgramDao
import com.pocketwin.data.ProgramEntity
import com.pocketwin.diagnostics.PwLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException

data class SourceInfo(val name: String, val size: Long)

/** Copies programs into app-private storage. Importing NEVER executes anything. */
class ProgramImporter(
    private val context: Context,
    private val paths: AppPaths,
    private val dao: ProgramDao,
    private val settings: SettingsStore
) {
    suspend fun describe(uri: Uri): SourceInfo = withContext(Dispatchers.IO) {
        var name = uri.lastPathSegment ?: "file"
        var size = -1L
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (t: Exception) {
            PwLog.w("Import", "describe failed", t)
        }
        SourceInfo(name, size)
    }

    suspend fun peek(uri: Uri): PeInfo = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { PeParser.parse(it) }
                ?: PeInfo(FileKind.UNKNOWN, PeArch.NOT_PE)
        } catch (t: Exception) {
            PeInfo(FileKind.UNKNOWN, PeArch.NOT_PE)
        }
    }

    fun listSamples(): List<String> =
        (context.assets.list("testapp") ?: emptyArray()).filter { it.endsWith(".exe") }.sorted()

    suspend fun importSingle(uri: Uri, containerId: String, displayName: String?): OpResult<ProgramEntity> =
        withContext(Dispatchers.IO) {
            val src = describe(uri)
            val fileName = TextUtil.sanitizeName(src.name)
            val id = UUID.randomUUID().toString()
            val dir = paths.programDir(id)
            try {
                dir.mkdirs()
                val input = context.contentResolver.openInputStream(uri)
                    ?: return@withContext fail(dir, "Cannot open the selected file")
                input.use { i -> File(dir, fileName).outputStream().use { o -> copyStream(i, o) } }
                finishImport(id, dir, fileName, containerId, displayName?.ifBlank { null } ?: fileName.substringBeforeLast('.'))
            } catch (e: CancellationException) {
                FileUtil.deleteTree(dir)
                throw e
            } catch (t: Exception) {
                fail(dir, "Import failed: ${t.message}")
            }
        }

    suspend fun importAsset(assetName: String, containerId: String): OpResult<ProgramEntity> =
        withContext(Dispatchers.IO) {
            val id = UUID.randomUUID().toString()
            val dir = paths.programDir(id)
            try {
                dir.mkdirs()
                context.assets.open("testapp/$assetName").use { i ->
                    File(dir, assetName).outputStream().use { o -> copyStream(i, o) }
                }
                val nice = assetName.removeSuffix(".exe").replace('_', ' ')
                finishImport(id, dir, assetName, containerId, nice)
            } catch (t: Exception) {
                fail(dir, "Import failed: ${t.message}")
            }
        }

    suspend fun scanExecutables(tree: Uri): List<String> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, tree) ?: return@withContext emptyList<String>()
        val out = ArrayList<String>()
        scanDir(root, "", 0, out)
        out.sort()
        out
    }

    private fun scanDir(d: DocumentFile, prefix: String, depth: Int, out: MutableList<String>) {
        if (depth > 4 || out.size >= 300) return
        for (c in d.listFiles()) {
            val n = TextUtil.sanitizeName(c.name ?: continue)
            if (c.isDirectory) {
                scanDir(c, "$prefix$n/", depth + 1, out)
            } else {
                val l = n.lowercase()
                if (l.endsWith(".exe") || l.endsWith(".msi")) out.add(prefix + n)
            }
        }
    }

    suspend fun importFolder(
        tree: Uri,
        exeRelPath: String,
        containerId: String,
        displayName: String?,
        onProgress: (Int) -> Unit
    ): OpResult<ProgramEntity> = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, tree)
            ?: return@withContext OpResult.failed<ProgramEntity>("Cannot open the selected folder")
        val id = UUID.randomUUID().toString()
        val dir = paths.programDir(id)
        try {
            dir.mkdirs()
            copyDoc(root, dir, 0, IntArray(1), onProgress)
            if (!File(dir, exeRelPath).isFile) return@withContext fail(dir, "Selected executable was not copied: $exeRelPath")
            finishImport(
                id, dir, exeRelPath, containerId,
                displayName?.ifBlank { null } ?: exeRelPath.substringAfterLast('/').substringBeforeLast('.')
            )
        } catch (e: CancellationException) {
            FileUtil.deleteTree(dir)
            throw e
        } catch (t: Exception) {
            fail(dir, "Import failed: ${t.message}")
        }
    }

    private suspend fun copyDoc(doc: DocumentFile, target: File, depth: Int, counter: IntArray, onProgress: (Int) -> Unit) {
        if (depth > 24) return
        target.mkdirs()
        for (child in doc.listFiles()) {
            currentCoroutineContext().ensureActive()
            val n = TextUtil.sanitizeName(child.name ?: continue)
            if (child.isDirectory) {
                copyDoc(child, File(target, n), depth + 1, counter, onProgress)
            } else if (child.isFile) {
                context.contentResolver.openInputStream(child.uri)?.use { i ->
                    File(target, n).outputStream().use { o -> copyStream(i, o) }
                }
                counter[0]++
                onProgress(counter[0])
            }
        }
    }

    /** Adds an executable that an installer created inside a container prefix. */
    suspend fun addFromPrefix(containerId: String, relPath: String, name: String?): OpResult<ProgramEntity> =
        withContext(Dispatchers.IO) {
            val prefix = paths.prefixDir(containerId)
            val exe = File(prefix, relPath)
            if (!exe.isFile) return@withContext OpResult.failed<ProgramEntity>("File not found: $relPath")
            val pe = PeParser.parse(exe)
            if (pe.kind != FileKind.PE || pe.isDll) return@withContext OpResult.failed<ProgramEntity>("Not a runnable Windows executable")
            val e = newEntity(
                UUID.randomUUID().toString(), name ?: exe.nameWithoutExtension, exe.name, ProgramKind.EXE,
                ProgramLocation.PREFIX, prefix.absolutePath, relPath, pe, containerId
            )
            dao.upsert(e)
            OpResult.success(e, "Added")
        }

    private suspend fun finishImport(id: String, dir: File, exeRel: String, containerId: String, name: String): OpResult<ProgramEntity> {
        val file = File(dir, exeRel)
        val lower = exeRel.lowercase()
        val kind: ProgramKind
        val pe: PeInfo
        if (lower.endsWith(".msi")) {
            kind = ProgramKind.MSI
            pe = PeParser.parse(file)
            if (pe.kind != FileKind.OLE_COMPOUND) return fail(dir, "The .msi file has no valid MSI header")
        } else {
            kind = ProgramKind.EXE
            pe = PeParser.parse(file)
            if (pe.kind != FileKind.PE) return fail(dir, "Not a valid Windows executable (no PE header)")
            if (pe.isDll) return fail(dir, "This file is a DLL and cannot be run directly")
        }
        val e = newEntity(id, name, file.name, kind, ProgramLocation.IMPORTED, dir.absolutePath, exeRel, pe, containerId)
        dao.upsert(e)
        PwLog.i("Import", "imported ${file.name} arch=${pe.arch}")
        return OpResult.success(e, "Imported")
    }

    private fun newEntity(
        id: String, name: String, fileName: String, kind: ProgramKind, loc: ProgramLocation,
        baseDir: String, rel: String, pe: PeInfo, containerId: String
    ): ProgramEntity {
        val s = settings.state.value
        return ProgramEntity(
            id = id, name = name, fileName = fileName, kind = kind.name, location = loc.name,
            baseDir = baseDir, exeRelPath = rel, arch = pe.arch.name, isDotNet = pe.isDotNet,
            containerId = containerId, graphicsMode = s.performance, resolution = s.defaultResolution,
            addedAt = System.currentTimeMillis(), compat = CompatState.UNTESTED.name
        )
    }

    private fun fail(dir: File, msg: String): OpResult<ProgramEntity> {
        FileUtil.deleteTree(dir)
        return OpResult.failed(msg)
    }

    private fun copyStream(i: InputStream, o: OutputStream) {
        val buf = ByteArray(65536)
        while (true) {
            val n = i.read(buf)
            if (n < 0) break
            o.write(buf, 0, n)
        }
    }
}
