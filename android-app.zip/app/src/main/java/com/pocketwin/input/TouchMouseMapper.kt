package com.pocketwin.input

enum class MouseButton { LEFT, RIGHT }

sealed interface MouseEvent {
    data class Move(val dx: Float, val dy: Float) : MouseEvent
    data class Button(val button: MouseButton, val down: Boolean) : MouseEvent
    data class Scroll(val dy: Float) : MouseEvent
}

fun interface InputSink {
    fun send(e: MouseEvent)
}

/** Counts events only. Forwarding to Wine is NOT implemented until a display backend exists. */
class CountingInputSink : InputSink {
    @Volatile
    var count: Int = 0
        private set

    override fun send(e: MouseEvent) {
        count++
    }
}

/** Touch gestures to mouse events: tap = left click, long press = right click, drag = move, two fingers = scroll. */
class TouchMouseMapper(private val sink: InputSink) {
    fun tap() = click(MouseButton.LEFT)

    fun longPress() = click(MouseButton.RIGHT)

    fun drag(dx: Float, dy: Float, pointers: Int) {
        if (pointers >= 2) sink.send(MouseEvent.Scroll(dy)) else sink.send(MouseEvent.Move(dx, dy))
    }

    private fun click(b: MouseButton) {
        sink.send(MouseEvent.Button(b, true))
        sink.send(MouseEvent.Button(b, false))
    }
}
