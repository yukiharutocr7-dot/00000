@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pocketwin.R
import com.pocketwin.container.ContainerStatus
import com.pocketwin.core.ContainerState
import com.pocketwin.data.ContainerEntity
import kotlinx.coroutines.launch

private sealed interface CDialog {
    object Create : CDialog
    data class Rename(val c: ContainerEntity) : CDialog
    data class Clone(val c: ContainerEntity) : CDialog
    data class Reset(val c: ContainerEntity) : CDialog
    data class Delete(val c: ContainerEntity) : CDialog
    data class Scan(val c: ContainerEntity, val files: List<String>) : CDialog
}

@Composable
fun ContainersScreen(vm: MainViewModel) {
    val g = vm.g
    val scope = rememberCoroutineScope()
    val containers by vm.containers.collectAsStateWithLifecycle()
    var statuses by remember { mutableStateOf<Map<String, ContainerStatus>>(emptyMap()) }
    var tick by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf<CDialog?>(null) }
    var text by remember { mutableStateOf("") }
    var busyId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(containers, tick) {
        val m = HashMap<String, ContainerStatus>()
        for (c in containers) g.containers.getContainerStatus(c.id).value?.let { m[c.id] = it }
        statuses = m
    }

    fun report(msg: String) {
        vm.message.value = msg
        tick++
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.containers_title), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            FilledTonalButton(onClick = { text = ""; dialog = CDialog.Create }) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.containers_new))
            }
        }
        if (containers.isEmpty()) EmptyState(stringResource(R.string.containers_empty))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            items(containers, key = { it.id }) { c ->
                val st = statuses[c.id]
                SectionCard(c.name) {
                    InfoRow(
                        stringResource(R.string.details_status),
                        if (c.initialized && c.state == ContainerState.READY.name) stringResource(R.string.containers_state_ready)
                        else stringResource(R.string.containers_state_created)
                    )
                    InfoRow(stringResource(R.string.containers_programs), (st?.programCount ?: 0).toString())
                    InfoRow(stringResource(R.string.containers_size), formatBytes(st?.sizeBytes ?: 0L))
                    if (c.wineVersion.isNotBlank()) InfoRow("Wine", c.wineVersion)
                    if (busyId == c.id) CircularProgressIndicator()
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(enabled = busyId == null, onClick = {
                            scope.launch {
                                busyId = c.id
                                val r = g.containers.ensureInitialized(c.id)
                                busyId = null
                                report(r.message.ifBlank { r.status.name })
                            }
                        }) { Text(stringResource(R.string.containers_init)) }
                        TextButton(onClick = { text = c.name; dialog = CDialog.Rename(c) }) { Text(stringResource(R.string.containers_rename)) }
                        TextButton(onClick = { text = c.name + " 2"; dialog = CDialog.Clone(c) }) { Text(stringResource(R.string.containers_clone)) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = {
                            scope.launch { dialog = CDialog.Scan(c, g.containers.scanInstalledExecutables(c.id)) }
                        }) { Text(stringResource(R.string.containers_scan)) }
                        TextButton(onClick = { dialog = CDialog.Reset(c) }) { Text(stringResource(R.string.containers_reset)) }
                        TextButton(onClick = { dialog = CDialog.Delete(c) }) { Text(stringResource(R.string.containers_delete)) }
                    }
                }
            }
        }
    }

    when (val d = dialog) {
        null -> {}
        is CDialog.Create, is CDialog.Rename, is CDialog.Clone -> {
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text(stringResource(R.string.containers_name)) },
                text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
                confirmButton = {
                    TextButton(onClick = {
                        val cur = d
                        dialog = null
                        scope.launch {
                            val r = when (cur) {
                                is CDialog.Rename -> g.containers.configureContainer(cur.c.id, text)
                                is CDialog.Clone -> g.containers.cloneContainer(cur.c.id, text)
                                else -> g.containers.createContainer(text)
                            }
                            report(r.message.ifBlank { r.status.name })
                        }
                    }) { Text(stringResource(R.string.action_confirm)) }
                },
                dismissButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.action_cancel)) } }
            )
        }
        is CDialog.Reset -> ConfirmDialog(stringResource(R.string.containers_confirm_reset, d.c.name), onNo = { dialog = null }) {
            dialog = null
            scope.launch { report(g.containers.resetContainer(d.c.id).message) }
        }
        is CDialog.Delete -> ConfirmDialog(stringResource(R.string.containers_confirm_delete, d.c.name), onNo = { dialog = null }) {
            dialog = null
            scope.launch { report(g.containers.deleteContainer(d.c.id).message) }
        }
        is CDialog.Scan -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(stringResource(R.string.containers_scan)) },
            text = {
                if (d.files.isEmpty()) {
                    Text(stringResource(R.string.containers_scan_empty))
                } else {
                    LazyColumn {
                        items(d.files) { f ->
                            TextButton(onClick = {
                                dialog = null
                                scope.launch {
                                    val r = g.importer.addFromPrefix(d.c.id, f, null)
                                    report(r.message.ifBlank { r.status.name })
                                }
                            }) { Text(f.removePrefix("drive_c/")) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.action_close)) } }
        )
    }
}

@Composable
private fun ConfirmDialog(text: String, onNo: () -> Unit, onYes: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onYes) { Text(stringResource(R.string.action_confirm)) } },
        dismissButton = { TextButton(onClick = onNo) { Text(stringResource(R.string.action_cancel)) } }
    )
}
