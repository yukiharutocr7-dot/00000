@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pocketwin.R

class MainActivity : PwActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PocketWinRoot() }
    }
}

@Composable
fun PocketWinRoot(vm: MainViewModel = viewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val dark = when (settings.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    PocketWinTheme(dark) {
        val nav = rememberNavController()
        val snack = remember { SnackbarHostState() }
        val msg by vm.message.collectAsStateWithLifecycle()
        LaunchedEffect(msg) {
            msg?.let {
                snack.showSnackbar(it)
                vm.message.value = null
            }
        }
        val backStack by nav.currentBackStackEntryAsState()
        val route = backStack?.destination?.route
        val topLevel = listOf(Routes.HOME, Routes.LIBRARY, Routes.CONTAINERS, Routes.SETTINGS)
        val items = listOf(
            Triple(Routes.HOME, R.string.nav_home, Icons.Filled.Home),
            Triple(Routes.LIBRARY, R.string.nav_library, Icons.Filled.PlayArrow),
            Triple(Routes.CONTAINERS, R.string.nav_containers, Icons.Filled.Menu),
            Triple(Routes.SETTINGS, R.string.nav_settings, Icons.Filled.Settings)
        )
        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                if (route in topLevel) {
                    NavigationBar {
                        items.forEach { (r, label, icon) ->
                            NavigationBarItem(
                                selected = route == r,
                                onClick = {
                                    nav.navigate(r) {
                                        popUpTo(Routes.HOME)
                                        launchSingleTop = true
                                    }
                                },
                                icon = { Icon(icon, null) },
                                label = { Text(stringResource(label)) }
                            )
                        }
                    }
                }
            }
        ) { pad ->
            NavHost(nav, startDestination = Routes.SPLASH, modifier = Modifier.padding(pad)) {
                composable(Routes.SPLASH) {
                    SplashScreen(vm) {
                        nav.navigate(Routes.HOME) { popUpTo(Routes.SPLASH) { inclusive = true } }
                    }
                }
                composable(Routes.HOME) { HomeScreen(vm, nav) }
                composable(Routes.LIBRARY) { LibraryScreen(vm, nav) }
                composable(Routes.IMPORT) { ImportScreen(vm, nav) }
                composable(Routes.CONTAINERS) { ContainersScreen(vm) }
                composable(Routes.COMPONENTS) { ComponentsScreen(vm, nav) }
                composable(Routes.SETTINGS) { SettingsScreen(vm, nav) }
                composable(Routes.DETAILS, arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                    DetailsScreen(vm, nav, e.arguments?.getString("id") ?: "")
                }
            }
        }
    }
}
