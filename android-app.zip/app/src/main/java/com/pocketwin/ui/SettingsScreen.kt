@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import android.app.Activity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.pocketwin.R
import com.pocketwin.core.FileUtil
import com.pocketwin.diagnostics.PwLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(vm: MainViewModel, nav: NavController) {
    val g = vm.g
    val s by vm.settings.collectAsStateWithLifecycle()
    val device by vm.device.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var sizes by remember { mutableStateOf(Triple(0L, 0L, 0L)) }
    var diag by remember { mutableStateOf("") }
    var logText by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableStateOf(0) }

    LaunchedEffect(tick) {
        withContext(Dispatchers.IO) {
            sizes = Triple(FileUtil.sizeOf(g.paths.programs), FileUtil.sizeOf(g.paths.containers), FileUtil.sizeOf(g.paths.runtime))
            diag = g.runtime.getRuntimeDiagnostics()
        }
    }

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(stringResource(R.string.nav_settings), style = MaterialTheme.typography.headlineSmall)

        SectionCard(stringResource(R.string.settings_language)) {
            ChipRow(listOf("ar" to "العربية", "en" to "English"), s.language) { v ->
                g.settings.update { it.copy(language = v) }
                (ctx as? Activity)?.recreate()
            }
        }
        SectionCard(stringResource(R.string.settings_theme)) {
            ChipRow(
                listOf(
                    "system" to stringResource(R.string.theme_system),
                    "light" to stringResource(R.string.theme_light),
                    "dark" to stringResource(R.string.theme_dark)
                ),
                s.theme
            ) { v -> g.settings.update { it.copy(theme = v) } }
        }
        SectionCard(stringResource(R.string.settings_resolution)) {
            ChipRow(listOf("800x600", "1024x768", "1280x720", "1920x1080").map { it to it }, s.defaultResolution) { v ->
                g.settings.update { it.copy(defaultResolution = v) }
            }
        }
        SectionCard(stringResource(R.string.settings_performance)) {
            ChipRow(
                listOf(
                    "compat" to stringResource(R.string.perf_compat),
                    "balanced" to stringResource(R.string.perf_balanced),
                    "performance" to stringResource(R.string.perf_performance)
                ),
                s.performance
            ) { v -> g.settings.update { it.copy(performance = v) } }
            Text(stringResource(R.string.graphics_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SectionCard(stringResource(R.string.settings_compat)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.settings_headless))
                    Text(stringResource(R.string.settings_headless_desc), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = s.allowHeadless, onCheckedChange = { v -> g.settings.update { it.copy(allowHeadless = v) } })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.settings_touch), modifier = Modifier.weight(1f))
                Switch(checked = s.touchMouse, onCheckedChange = { v -> g.settings.update { it.copy(touchMouse = v) } })
            }
        }
        SectionCard(stringResource(R.string.settings_storage)) {
            InfoRow(stringResource(R.string.settings_programs_size), formatBytes(sizes.first))
            InfoRow(stringResource(R.string.settings_containers_size), formatBytes(sizes.second))
            InfoRow(stringResource(R.string.settings_runtime_size), formatBytes(sizes.third))
            device?.let { InfoRow(stringResource(R.string.dev_storage), "${it.storageFreeMb} MB") }
            OutlinedButton(onClick = {
                scope.launch(Dispatchers.IO) {
                    FileUtil.deleteTree(g.paths.downloads)
                    FileUtil.deleteTree(g.paths.tmp)
                    g.paths.ensure()
                    tick++
                }
            }) { Text(stringResource(R.string.settings_clear_cache)) }
        }
        SectionCard(stringResource(R.string.settings_device)) {
            val d = device
            if (d == null) {
                Text(stringResource(R.string.common_unknown))
            } else {
                InfoRow(stringResource(R.string.dev_android), "${d.release} (API ${d.sdk})")
                InfoRow(stringResource(R.string.dev_abi), d.abis.joinToString())
                InfoRow(stringResource(R.string.dev_soc), d.socModel)
                InfoRow(stringResource(R.string.dev_ram), "${d.ramTotalMb} MB")
                InfoRow(stringResource(R.string.dev_vulkan), d.vulkanVersion ?: stringResource(R.string.dev_not_reported))
                InfoRow(stringResource(R.string.dev_gl), d.glEsVersion.ifBlank { stringResource(R.string.dev_not_reported) })
                d.blockers.forEach { Text(blockerLabel(it), color = MaterialTheme.colorScheme.error) }
            }
        }
        SectionCard(stringResource(R.string.settings_diagnostics)) {
            Text(diag, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { clipboard.setText(AnnotatedString(diag)) }) { Text(stringResource(R.string.action_copy)) }
                OutlinedButton(onClick = { tick++ }) { Text(stringResource(R.string.action_refresh)) }
            }
        }
        SectionCard(stringResource(R.string.settings_logs)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { logText = PwLog.tail(PwLog.logFile(), 12000) }) { Text(stringResource(R.string.settings_view_log)) }
                OutlinedButton(onClick = {
                    PwLog.logFile()?.writeText("")
                    vm.message.value = ctx.getString(R.string.settings_log_cleared)
                }) { Text(stringResource(R.string.settings_clear_logs)) }
            }
        }
    }

    logText?.let { t ->
        AlertDialog(
            onDismissRequest = { logText = null },
            title = { Text(stringResource(R.string.settings_logs)) },
            text = {
                Text(
                    t.ifBlank { "-" }, fontFamily = FontFamily.Monospace, fontSize = 10.sp,
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            },
            confirmButton = { TextButton(onClick = { logText = null }) { Text(stringResource(R.string.action_close)) } }
        )
    }
}
