@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.pocketwin.R
import com.pocketwin.core.FileKind
import com.pocketwin.core.OpResult
import com.pocketwin.core.PeArch
import com.pocketwin.core.PeInfo
import com.pocketwin.data.ProgramEntity
import com.pocketwin.program.SourceInfo
import kotlinx.coroutines.launch

private enum class ImportMode { FILE, FOLDER, SAMPLE }

@Composable
fun ImportScreen(vm: MainViewModel, nav: NavController) {
    val g = vm.g
    val scope = rememberCoroutineScope()
    val containers by vm.containers.collectAsStateWithLifecycle()
    val samples = remember { g.importer.listSamples() }

    var mode by remember { mutableStateOf(ImportMode.FILE) }
    var fileUri by remember { mutableStateOf<Uri?>(null) }
    var treeUri by remember { mutableStateOf<Uri?>(null) }
    var info by remember { mutableStateOf<SourceInfo?>(null) }
    var pe by remember { mutableStateOf<PeInfo?>(null) }
    var exeList by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedExe by remember { mutableStateOf<String?>(null) }
    var selectedSample by remember { mutableStateOf(samples.firstOrNull()) }
    var containerId by remember { mutableStateOf<String?>(null) }
    var name by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var copied by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf<OpResult<ProgramEntity>?>(null) }
    var scanning by remember { mutableStateOf(false) }

    LaunchedEffect(containers) {
        if (containerId == null || containers.none { it.id == containerId }) containerId = containers.firstOrNull()?.id
    }

    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            fileUri = uri
            result = null
            scope.launch {
                val i = g.importer.describe(uri)
                info = i
                pe = g.importer.peek(uri)
                name = i.name.substringBeforeLast('.')
            }
        }
    }
    val pickTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            treeUri = uri
            result = null
            scope.launch {
                scanning = true
                exeList = g.importer.scanExecutables(uri)
                selectedExe = exeList.firstOrNull()
                name = selectedExe?.substringAfterLast('/')?.substringBeforeLast('.') ?: ""
                scanning = false
            }
        }
    }

    val canImport = !working && containerId != null && when (mode) {
        ImportMode.FILE -> fileUri != null
        ImportMode.FOLDER -> treeUri != null && selectedExe != null
        ImportMode.SAMPLE -> selectedSample != null
    }

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(stringResource(R.string.import_title), style = MaterialTheme.typography.headlineSmall)
        ChipRow(
            listOf(
                ImportMode.FILE.name to stringResource(R.string.import_pick_file),
                ImportMode.FOLDER.name to stringResource(R.string.import_pick_folder),
                ImportMode.SAMPLE.name to stringResource(R.string.import_sample)
            ),
            mode.name
        ) { mode = ImportMode.valueOf(it); result = null }

        when (mode) {
            ImportMode.FILE -> {
                OutlinedButton(onClick = { pickFile.launch(arrayOf("*/*")) }) { Text(stringResource(R.string.import_pick_file)) }
                info?.let { i ->
                    SectionCard(stringResource(R.string.import_selected)) {
                        InfoRow(stringResource(R.string.import_name), i.name)
                        InfoRow(stringResource(R.string.import_size), if (i.size >= 0) formatBytes(i.size) else stringResource(R.string.common_unknown))
                        pe?.let { p -> ArchInfo(p, i.name) }
                    }
                }
            }
            ImportMode.FOLDER -> {
                OutlinedButton(onClick = { pickTree.launch(null) }) { Text(stringResource(R.string.import_pick_folder)) }
                if (scanning) CircularProgressIndicator()
                if (treeUri != null && !scanning) {
                    if (exeList.isEmpty()) {
                        Text(stringResource(R.string.import_no_exe_found), color = MaterialTheme.colorScheme.error)
                    } else {
                        Text(stringResource(R.string.import_choose_exe), style = MaterialTheme.typography.titleSmall)
                        ChipRow(exeList.take(40).map { it to it }, selectedExe ?: "") {
                            selectedExe = it
                            name = it.substringAfterLast('/').substringBeforeLast('.')
                        }
                    }
                }
            }
            ImportMode.SAMPLE -> {
                if (samples.isEmpty()) {
                    Text(stringResource(R.string.import_no_sample), color = MaterialTheme.colorScheme.error)
                } else {
                    ChipRow(samples.map { it to it }, selectedSample ?: "") { selectedSample = it }
                }
            }
        }

        if (containers.isNotEmpty()) {
            Text(stringResource(R.string.import_container), style = MaterialTheme.typography.titleSmall)
            ChipRow(containers.map { it.id to it.name }, containerId ?: "") { containerId = it }
        }
        if (mode != ImportMode.SAMPLE) {
            OutlinedTextField(
                value = name, onValueChange = { name = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.import_name)) }
            )
        }
        Text(stringResource(R.string.import_no_autorun), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Button(
            enabled = canImport,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val cid = containerId
                if (cid != null) scope.launch {
                    working = true
                    copied = 0
                    result = when (mode) {
                        ImportMode.FILE -> {
                            val u = fileUri
                            if (u != null) g.importer.importSingle(u, cid, name)
                            else OpResult.failed<ProgramEntity>("No file selected")
                        }
                        ImportMode.FOLDER -> {
                            val t = treeUri
                            val e = selectedExe
                            if (t != null && e != null) g.importer.importFolder(t, e, cid, name) { copied = it }
                            else OpResult.failed<ProgramEntity>("No folder selected")
                        }
                        ImportMode.SAMPLE -> {
                            val s = selectedSample
                            if (s != null) g.importer.importAsset(s, cid)
                            else OpResult.failed<ProgramEntity>("No sample selected")
                        }
                    }
                    working = false
                }
            }
        ) { Text(stringResource(R.string.import_start)) }

        if (working) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator()
                Text(stringResource(R.string.import_progress, copied))
            }
        }
        result?.let { r ->
            if (r.ok) {
                val p = r.value
                Text(stringResource(R.string.import_done), color = MaterialTheme.colorScheme.primary)
                if (p != null) {
                    Button(onClick = { nav.navigate(Routes.details(p.id)) }) { Text(stringResource(R.string.action_details)) }
                }
            } else {
                Text(stringResource(R.string.import_failed) + " " + r.message, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun ArchInfo(p: PeInfo, fileName: String) {
    val isMsi = fileName.lowercase().endsWith(".msi") && p.kind == FileKind.OLE_COMPOUND
    InfoRow(stringResource(R.string.import_arch), if (isMsi) "MSI" else archLabel(p.arch.name))
    val warn = when {
        isMsi -> null
        p.kind != FileKind.PE -> R.string.import_warn_not_pe
        p.isDll -> R.string.import_warn_dll
        p.arch == PeArch.ARM64 || p.arch == PeArch.ARM -> R.string.import_warn_arm
        p.arch == PeArch.X86 -> R.string.import_warn_32
        else -> null
    }
    if (warn != null) Text(stringResource(warn), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
}
