@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.pocketwin.R
import com.pocketwin.data.ProgramEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DetailsScreen(vm: MainViewModel, nav: NavController, id: String) {
    val g = vm.g
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val containers by vm.containers.collectAsStateWithLifecycle()
    var program by remember { mutableStateOf<ProgramEntity?>(null) }
    var meta by remember { mutableStateOf<ProgramEntity?>(null) }
    var log by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    val run = rememberRunAction(vm)

    var name by remember { mutableStateOf("") }
    var args by remember { mutableStateOf("") }
    var env by remember { mutableStateOf("") }
    var deps by remember { mutableStateOf("") }
    var resolution by remember { mutableStateOf("1280x720") }
    var graphics by remember { mutableStateOf("balanced") }
    var containerId by remember { mutableStateOf("") }

    suspend fun reload(initial: Boolean) {
        val p = withContext(Dispatchers.IO) { g.db.programDao().get(id) }
        meta = p
        log = withContext(Dispatchers.IO) { g.runner.getProgramLogs(id, 12000) }
        if (initial && p != null) {
            program = p
            name = p.name; args = p.args; env = p.envVars; deps = p.dependencies
            resolution = p.resolution; graphics = p.graphicsMode; containerId = p.containerId
        }
    }
    LaunchedEffect(id) { reload(true) }

    val p = program
    if (p == null) {
        EmptyState(stringResource(R.string.common_unknown))
        return
    }
    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(p.name, style = MaterialTheme.typography.headlineSmall)
        SectionCard(stringResource(R.string.details_info)) {
            InfoRow(stringResource(R.string.details_path), p.exeRelPath)
            InfoRow(stringResource(R.string.details_arch), archLabel(p.arch) + if (p.isDotNet) " (.NET)" else "")
            InfoRow(stringResource(R.string.details_status), compatLabel(meta?.compat ?: p.compat))
            InfoRow(stringResource(R.string.details_last_result), meta?.lastResult?.ifBlank { "-" } ?: "-")
        }
        OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.import_name)) })
        Text(stringResource(R.string.details_container), style = MaterialTheme.typography.titleSmall)
        ChipRow(containers.map { it.id to it.name }, containerId) { containerId = it }
        Text(stringResource(R.string.details_graphics), style = MaterialTheme.typography.titleSmall)
        ChipRow(
            listOf(
                "compat" to stringResource(R.string.perf_compat),
                "balanced" to stringResource(R.string.perf_balanced),
                "performance" to stringResource(R.string.perf_performance)
            ),
            graphics
        ) { graphics = it }
        Text(stringResource(R.string.graphics_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(stringResource(R.string.details_resolution), style = MaterialTheme.typography.titleSmall)
        ChipRow(listOf("800x600", "1024x768", "1280x720", "1920x1080").map { it to it }, resolution) { resolution = it }
        OutlinedTextField(value = args, onValueChange = { args = it }, modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.details_args)) })
        OutlinedTextField(value = env, onValueChange = { env = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, label = { Text(stringResource(R.string.details_env)) })
        OutlinedTextField(value = deps, onValueChange = { deps = it }, modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.details_deps)) })

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                scope.launch {
                    val cur = withContext(Dispatchers.IO) { g.db.programDao().get(id) } ?: p
                    g.db.programDao().upsert(
                        cur.copy(
                            name = name.ifBlank { cur.name }, args = args, envVars = env, dependencies = deps,
                            resolution = resolution, graphicsMode = graphics, containerId = containerId.ifBlank { cur.containerId }
                        )
                    )
                    saved = true
                    reload(false)
                }
            }) { Text(stringResource(R.string.action_save)) }
            Button(onClick = { run(meta ?: p) }) { Text(stringResource(R.string.action_run)) }
        }
        OutlinedButton(onClick = {
            val cur = meta ?: p
            if (cur.trusted) {
                vm.installerProgram(id)
                startSession(ctx, id, autoLaunch = false)
            } else {
                run(cur)
            }
        }) { Text(stringResource(R.string.details_run_installer)) }
        if (saved) Text(stringResource(R.string.details_saved), color = MaterialTheme.colorScheme.primary)

        SectionCard(stringResource(R.string.details_log)) {
            Text(
                if (log.isBlank()) "-" else log,
                fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).verticalScroll(rememberScrollState())
                    .background(MaterialTheme.colorScheme.surfaceVariant).padding(8.dp)
            )
            OutlinedButton(onClick = { scope.launch { reload(false) } }) { Text(stringResource(R.string.action_refresh)) }
        }
    }
}
