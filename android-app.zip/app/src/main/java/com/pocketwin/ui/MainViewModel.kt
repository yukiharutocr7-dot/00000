package com.pocketwin.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pocketwin.Graph
import com.pocketwin.PocketWinApp
import com.pocketwin.data.ContainerEntity
import com.pocketwin.data.ProgramEntity
import com.pocketwin.device.DeviceCapabilities
import com.pocketwin.diagnostics.PwLog
import com.pocketwin.runtime.ComponentStatus
import com.pocketwin.runtime.RuntimeComponent
import com.pocketwin.runtime.RuntimeStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class InitState { IDLE, RUNNING, DONE, ERROR }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val g: Graph = (app as PocketWinApp).graph
    private val programDao = g.db.programDao()

    val programs: StateFlow<List<ProgramEntity>> =
        programDao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val containers: StateFlow<List<ContainerEntity>> =
        g.db.containerDao().observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val settings = g.settings.state
    val sessions = g.sessions.sessions

    val device = MutableStateFlow<DeviceCapabilities?>(null)
    val runtimeStatus = MutableStateFlow<RuntimeStatus?>(null)
    val components = MutableStateFlow<List<ComponentStatus>>(emptyList())
    val busyLabel = MutableStateFlow<String?>(null)
    val progress = MutableStateFlow<Float?>(null)
    val message = MutableStateFlow<String?>(null)
    val initState = MutableStateFlow(InitState.IDLE)
    val initError = MutableStateFlow<String?>(null)

    private var started = false

    fun initialize() {
        if (started) return
        started = true
        initState.value = InitState.RUNNING
        initError.value = null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                device.value = g.device.collect()
                g.runtime.initializeRuntime()
                g.containers.ensureDefaultContainer()
                refreshRuntimeInternal()
                initState.value = InitState.DONE
            } catch (t: Throwable) {
                PwLog.e("Init", "initialization failed", t)
                initError.value = t.message ?: t.javaClass.simpleName
                initState.value = InitState.ERROR
            }
        }
    }

    fun retryInit() {
        started = false
        initialize()
    }

    private suspend fun refreshRuntimeInternal() {
        runtimeStatus.value = g.runtime.getRuntimeStatus()
        components.value = g.runtime.listRuntimeComponents()
        device.value = g.device.collect()
    }

    fun refreshRuntime() {
        viewModelScope.launch(Dispatchers.IO) { refreshRuntimeInternal() }
    }

    private fun runBusy(label: String, block: suspend () -> Unit) {
        if (busyLabel.value != null) return
        busyLabel.value = label
        progress.value = null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                block()
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) throw t
                PwLog.e("Busy", "operation failed", t)
                message.value = t.message ?: t.javaClass.simpleName
            } finally {
                busyLabel.value = null
                progress.value = null
                refreshRuntimeInternal()
            }
        }
    }

    private fun report(done: Long, total: Long) {
        progress.value = if (total > 0) (done.toFloat() / total.toFloat()).coerceIn(0f, 1f) else null
    }

    fun fetchManifest() = runBusy("manifest") {
        val url = g.settings.state.value.manifestUrl.trim()
        val r = g.runtime.fetchManifest(url)
        message.value = r.message.ifBlank { r.status.name }
    }

    fun updateRuntime() = runBusy("update") {
        val r = g.runtime.updateRuntime { id, d, t ->
            busyLabel.value = id
            report(d, t)
        }
        message.value = r.message.ifBlank { r.status.name }
    }

    fun installComponent(c: RuntimeComponent) = runBusy(c.id) {
        val r = g.runtime.installComponent(c) { d, t -> report(d, t) }
        message.value = r.message.ifBlank { r.status.name }
    }

    fun removeComponent(id: String) = runBusy(id) {
        message.value = g.runtime.removeComponent(id).message
    }

    fun markTrustedThen(p: ProgramEntity, then: () -> Unit) {
        viewModelScope.launch {
            programDao.upsert(p.copy(trusted = true))
            then()
        }
    }

    fun toggleFavorite(p: ProgramEntity) {
        viewModelScope.launch { programDao.upsert(p.copy(favorite = !p.favorite)) }
    }

    fun deleteProgram(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val r = g.runner.deleteProgram(id)
            if (!r.ok) message.value = r.message
        }
    }

    /** Runs on the application scope so a launch continues when the session screen is closed. */
    fun launchProgram(id: String) {
        g.scope.launch(Dispatchers.IO) { g.runner.launchProgram(id) }
    }

    fun installerProgram(id: String) {
        g.scope.launch(Dispatchers.IO) { g.runner.installProgram(id) }
    }

    fun stopProgram(id: String) {
        g.scope.launch(Dispatchers.IO) { g.runner.stopProgram(id) }
    }

    fun restartProgram(id: String) {
        g.scope.launch(Dispatchers.IO) { g.runner.restartProgram(id) }
    }
}
