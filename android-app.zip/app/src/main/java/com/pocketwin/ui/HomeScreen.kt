@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.pocketwin.R

@Composable
fun HomeScreen(vm: MainViewModel, nav: NavController) {
    val programs by vm.programs.collectAsStateWithLifecycle()
    val containers by vm.containers.collectAsStateWithLifecycle()
    val status by vm.runtimeStatus.collectAsStateWithLifecycle()
    val device by vm.device.collectAsStateWithLifecycle()
    val run = rememberRunAction(vm)
    val recent = programs.filter { it.lastRunAt > 0 }.sortedByDescending { it.lastRunAt }.take(3)

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(stringResource(R.string.app_title_full), style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(stringResource(R.string.home_programs), programs.size.toString(), Modifier.weight(1f))
            StatCard(stringResource(R.string.home_containers), containers.size.toString(), Modifier.weight(1f))
        }
        SectionCard(stringResource(R.string.home_runtime)) {
            val st = status
            Text(if (st == null) stringResource(R.string.common_unknown) else runtimeStateLabel(st.state))
            if (st != null && st.missing.isNotEmpty()) {
                Text(st.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            device?.blockers?.forEach {
                Text(blockerLabel(it), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = { nav.navigate(Routes.COMPONENTS) }) { Text(stringResource(R.string.home_components)) }
        }
        SectionCard(stringResource(R.string.home_recent)) {
            if (recent.isEmpty()) {
                Text(stringResource(R.string.home_no_recent), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            recent.forEach { p ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(p.name, modifier = Modifier.weight(1f))
                    IconButton(onClick = { run(p) }) { Icon(Icons.Filled.PlayArrow, stringResource(R.string.action_run)) }
                }
            }
        }
        Button(onClick = { nav.navigate(Routes.IMPORT) }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Add, null)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.home_add))
        }
        OutlinedButton(onClick = { nav.navigate(Routes.CONTAINERS) }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.home_manage_containers))
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineMedium)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
