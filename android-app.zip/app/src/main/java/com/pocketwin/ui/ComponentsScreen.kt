@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.pocketwin.R

@Composable
fun ComponentsScreen(vm: MainViewModel, nav: NavController) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val comps by vm.components.collectAsStateWithLifecycle()
    val status by vm.runtimeStatus.collectAsStateWithLifecycle()
    val busy by vm.busyLabel.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.refreshRuntime() }

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(stringResource(R.string.components_title), style = MaterialTheme.typography.headlineSmall)
        status?.let { st ->
            Text(runtimeStateLabel(st.state))
            if (st.missing.isNotEmpty()) Text(st.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        OutlinedTextField(
            value = settings.manifestUrl,
            onValueChange = { v -> vm.g.settings.update { it.copy(manifestUrl = v) } },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.components_manifest_url)) },
            supportingText = { Text(stringResource(R.string.components_https_note)) }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = busy == null && settings.manifestUrl.isNotBlank(), onClick = { vm.fetchManifest() }) {
                Text(stringResource(R.string.components_fetch))
            }
            Button(enabled = busy == null && settings.manifestUrl.isNotBlank(), onClick = { vm.updateRuntime() }) {
                Text(stringResource(R.string.components_update_all))
            }
        }
        if (busy != null) {
            Text(stringResource(R.string.components_working, busy ?: ""))
            val p = progress
            if (p != null) LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
            else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
        if (comps.isEmpty()) EmptyState(stringResource(R.string.components_empty))
        comps.forEach { cs ->
            val c = cs.component
            SectionCard(c.name) {
                InfoRow(stringResource(R.string.components_role), c.role)
                InfoRow(stringResource(R.string.components_version), c.version)
                if (c.sizeBytes > 0) InfoRow(stringResource(R.string.containers_size), formatBytes(c.sizeBytes))
                InfoRow(stringResource(R.string.components_license), c.license.ifBlank { "-" })
                if (c.sourceUrl.isNotBlank()) InfoRow(stringResource(R.string.components_source), c.sourceUrl)
                InfoRow(
                    stringResource(R.string.details_status),
                    when {
                        cs.installedVersion == null -> stringResource(R.string.components_not_installed)
                        !cs.healthy -> stringResource(R.string.components_broken)
                        else -> stringResource(R.string.components_installed) + " " + cs.installedVersion
                    }
                )
                if (cs.installedVersion != null) InfoRow(stringResource(R.string.containers_size), formatBytes(cs.sizeOnDisk))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (c.url.isNotBlank()) {
                        Button(enabled = busy == null, onClick = { vm.installComponent(c) }) {
                            Text(stringResource(R.string.components_install))
                        }
                    }
                    if (cs.installedVersion != null) {
                        OutlinedButton(enabled = busy == null, onClick = { vm.removeComponent(c.id) }) {
                            Text(stringResource(R.string.components_remove))
                        }
                    }
                }
            }
        }
    }
}
