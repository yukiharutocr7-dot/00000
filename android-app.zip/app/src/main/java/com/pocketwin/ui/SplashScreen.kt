@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pocketwin.R
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(vm: MainViewModel, onDone: () -> Unit) {
    val state by vm.initState.collectAsStateWithLifecycle()
    val err by vm.initError.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.initialize() }
    LaunchedEffect(state) {
        if (state == InitState.DONE) {
            delay(400)
            onDone()
        }
    }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("PocketWin", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.app_tagline), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(32.dp))
        if (state == InitState.ERROR) {
            Text(stringResource(R.string.splash_error), color = MaterialTheme.colorScheme.error)
            Text(err ?: "", textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.retryInit() }) { Text(stringResource(R.string.splash_retry)) }
                OutlinedButton(onClick = onDone) { Text(stringResource(R.string.splash_continue)) }
            }
        } else {
            CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.splash_preparing))
        }
    }
}
