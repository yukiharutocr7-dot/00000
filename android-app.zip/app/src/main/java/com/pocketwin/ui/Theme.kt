package com.pocketwin.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF1F3A5F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4F7),
    secondary = Color(0xFF3D7EAA),
    tertiary = Color(0xFF6B5B95)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9CC4EE),
    onPrimary = Color(0xFF0B2545),
    primaryContainer = Color(0xFF2B4A70),
    secondary = Color(0xFF8FC1E3),
    tertiary = Color(0xFFC0B2E8)
)

@Composable
fun PocketWinTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
