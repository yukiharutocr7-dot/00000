@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pocketwin.R
import com.pocketwin.core.CompatState
import com.pocketwin.core.PeArch
import com.pocketwin.core.RuntimeState
import com.pocketwin.data.ProgramEntity
import com.pocketwin.device.Blocker
import com.pocketwin.session.SessionPhase
import com.pocketwin.session.SessionState
import java.util.Locale

object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val LIBRARY = "library"
    const val IMPORT = "import"
    const val CONTAINERS = "containers"
    const val COMPONENTS = "components"
    const val SETTINGS = "settings"
    const val DETAILS = "details/{id}"
    fun details(id: String) = "details/$id"
}

const val EXTRA_PROGRAM_ID = "program_id"
const val EXTRA_AUTO_LAUNCH = "auto_launch"

fun startSession(ctx: Context, id: String, autoLaunch: Boolean = true) {
    ctx.startActivity(
        Intent(ctx, ProgramSessionActivity::class.java)
            .putExtra(EXTRA_PROGRAM_ID, id)
            .putExtra(EXTRA_AUTO_LAUNCH, autoLaunch)
    )
}

fun formatBytes(b: Long): String {
    if (b < 1024) return "$b B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = -1
    while (v >= 1024 && i < units.size - 1) {
        v /= 1024
        i++
    }
    return String.format(Locale.US, "%.1f %s", v, units[i])
}

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
            label, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.4f)
        )
        Text(value, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.End, modifier = Modifier.weight(0.6f))
    }
}

@Composable
fun EmptyState(text: String) {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

/** options = (value, label) */
@Composable
fun ChipRow(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 2.dp)) {
        items(options) { (value, label) ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
        }
    }
}

@Composable
fun archLabel(arch: String): String = when (arch) {
    PeArch.X64.name -> stringResource(R.string.arch_x64)
    PeArch.X86.name -> stringResource(R.string.arch_x86)
    PeArch.ARM64.name -> stringResource(R.string.arch_arm64)
    PeArch.ARM.name -> stringResource(R.string.arch_arm)
    PeArch.NOT_PE.name -> stringResource(R.string.arch_not_pe)
    else -> stringResource(R.string.common_unknown)
}

@Composable
fun runtimeStateLabel(s: RuntimeState): String = when (s) {
    RuntimeState.NOT_CONFIGURED -> stringResource(R.string.runtime_not_configured)
    RuntimeState.NOT_INSTALLED -> stringResource(R.string.runtime_not_installed)
    RuntimeState.PARTIAL -> stringResource(R.string.runtime_partial)
    RuntimeState.READY -> stringResource(R.string.runtime_ready)
}

@Composable
fun blockerLabel(b: Blocker): String = when (b) {
    Blocker.NO_ARM64 -> stringResource(R.string.blocker_no_arm64)
    Blocker.ANDROID_TOO_OLD -> stringResource(R.string.blocker_old)
    Blocker.LOW_STORAGE -> stringResource(R.string.blocker_storage)
    Blocker.LOW_RAM -> stringResource(R.string.blocker_ram)
}

@Composable
fun phaseLabel(p: SessionPhase): String = when (p) {
    SessionPhase.IDLE -> stringResource(R.string.session_idle)
    SessionPhase.PREPARING -> stringResource(R.string.session_preparing)
    SessionPhase.RUNNING -> stringResource(R.string.session_running)
    SessionPhase.EXITED -> stringResource(R.string.session_exited)
    SessionPhase.CRASHED -> stringResource(R.string.session_crashed)
    SessionPhase.FAILED -> stringResource(R.string.session_failed)
}

@Composable
fun compatLabel(c: String): String = when (c) {
    CompatState.RAN_OK.name -> stringResource(R.string.status_ran_ok)
    CompatState.FAILED.name -> stringResource(R.string.status_failed)
    else -> stringResource(R.string.status_untested)
}

@Composable
fun programStatusText(p: ProgramEntity, s: SessionState?): String {
    val live = s != null && (s.phase == SessionPhase.RUNNING || s.phase == SessionPhase.PREPARING)
    return if (live) phaseLabel(s!!.phase) else compatLabel(p.compat)
}

/** Returns the action to run a program. Shows the security warning before the first run. */
@Composable
fun rememberRunAction(vm: MainViewModel): (ProgramEntity) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<ProgramEntity?>(null) }
    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(stringResource(R.string.trust_title)) },
            text = { Text(stringResource(R.string.trust_body)) },
            confirmButton = {
                TextButton(onClick = {
                    pending = null
                    vm.markTrustedThen(p) { startSession(ctx, p.id) }
                }) { Text(stringResource(R.string.trust_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { pending = null }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }
    return { p ->
        if (p.trusted) {
            startSession(ctx, p.id)
        } else {
            pending = p
        }
    }
}

@Composable
fun ProgramRow(
    p: ProgramEntity,
    state: SessionState?,
    onOpen: () -> Unit,
    onRun: () -> Unit,
    onFav: () -> Unit,
    onDelete: () -> Unit
) {
    Card(onClick = onOpen, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) { Text(p.name.take(1).uppercase(), style = MaterialTheme.typography.titleMedium) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                Text(
                    archLabel(p.arch) + " \u2022 " + programStatusText(p, state),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onFav) {
                Icon(
                    Icons.Filled.Star, stringResource(R.string.action_favorite),
                    tint = if (p.favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                )
            }
            IconButton(onClick = onRun) { Icon(Icons.Filled.PlayArrow, stringResource(R.string.action_run)) }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, stringResource(R.string.action_delete)) }
        }
    }
}
