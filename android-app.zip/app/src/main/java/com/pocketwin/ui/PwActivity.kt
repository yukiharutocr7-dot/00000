package com.pocketwin.ui

import android.content.Context
import androidx.activity.ComponentActivity
import com.pocketwin.core.LocaleHelper

/** Base activity: applies the language chosen in Settings (Arabic by default, RTL). */
open class PwActivity : ComponentActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }
}
