@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.pocketwin.R
import com.pocketwin.data.ProgramEntity

@Composable
fun LibraryScreen(vm: MainViewModel, nav: NavController) {
    val programs by vm.programs.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val run = rememberRunAction(vm)
    var query by remember { mutableStateOf("") }
    var sortRecent by remember { mutableStateOf(false) }
    var onlyFav by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<ProgramEntity?>(null) }

    val filtered = programs.filter { (!onlyFav || it.favorite) && it.name.contains(query.trim(), ignoreCase = true) }
    val list = if (sortRecent) filtered.sortedByDescending { it.lastRunAt } else filtered

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.library_title), style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            FilledTonalButton(onClick = { nav.navigate(Routes.IMPORT) }) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.home_add))
            }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            placeholder = { Text(stringResource(R.string.library_search)) }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !sortRecent, onClick = { sortRecent = false }, label = { Text(stringResource(R.string.library_sort_name)) })
            FilterChip(selected = sortRecent, onClick = { sortRecent = true }, label = { Text(stringResource(R.string.library_sort_recent)) })
            FilterChip(selected = onlyFav, onClick = { onlyFav = !onlyFav }, label = { Text(stringResource(R.string.library_only_fav)) })
        }
        if (list.isEmpty()) {
            EmptyState(stringResource(R.string.library_empty))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                items(list, key = { it.id }) { p ->
                    ProgramRow(
                        p = p, state = sessions[p.id],
                        onOpen = { nav.navigate(Routes.details(p.id)) },
                        onRun = { run(p) },
                        onFav = { vm.toggleFavorite(p) },
                        onDelete = { toDelete = p }
                    )
                }
            }
        }
    }

    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text(stringResource(R.string.action_delete)) },
            text = { Text(p.name) },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteProgram(p.id)
                    toDelete = null
                }) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text(stringResource(R.string.action_cancel)) } }
        )
    }
}
