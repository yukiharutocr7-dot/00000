@file:OptIn(ExperimentalMaterial3Api::class)

package com.pocketwin.ui

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pocketwin.R
import com.pocketwin.data.ProgramEntity
import com.pocketwin.input.CountingInputSink
import com.pocketwin.input.TouchMouseMapper
import com.pocketwin.session.SessionPhase
import com.pocketwin.session.SessionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Screen that hosts a running program. The real rendering surface (Wine window via an X server) is NOT
 * implemented; this screen shows the true session state, logs and captures touch input.
 */
class ProgramSessionActivity : PwActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra(EXTRA_PROGRAM_ID)
        if (id == null) {
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (savedInstanceState == null && intent.getBooleanExtra(EXTRA_AUTO_LAUNCH, false)) vm.launchProgram(id)
        setContent {
            val s by vm.settings.collectAsStateWithLifecycle()
            val dark = when (s.theme) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }
            PocketWinTheme(dark) { SessionScreen(vm, id) { finish() } }
        }
    }
}

@Composable
fun SessionScreen(vm: MainViewModel, id: String, onExit: () -> Unit) {
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val st = sessions[id] ?: SessionState(id, SessionPhase.IDLE)
    var program by remember { mutableStateOf<ProgramEntity?>(null) }
    var controls by remember { mutableStateOf(true) }
    var showLog by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("") }
    var events by remember { mutableIntStateOf(0) }
    val sink = remember { CountingInputSink() }
    val mapper = remember { TouchMouseMapper { sink.send(it); events = sink.count } }

    LaunchedEffect(id) { program = withContext(Dispatchers.IO) { vm.g.db.programDao().get(id) } }
    LaunchedEffect(showLog, st.phase) {
        while (showLog) {
            log = withContext(Dispatchers.IO) { vm.g.runner.getProgramLogs(id, 6000) }
            delay(1000)
        }
    }
    BackHandler { onExit() }

    Box(Modifier.fillMaxSize().background(Color(0xFF101418))) {
        // Input capture area (touch -> mouse events). Events are counted, not forwarded to Wine.
        Box(
            Modifier.fillMaxSize()
                .pointerInput(settings.touchMouse) {
                    if (settings.touchMouse) {
                        detectTapGestures(onTap = { mapper.tap() }, onLongPress = { mapper.longPress() })
                    }
                }
                .pointerInput(settings.touchMouse) {
                    if (settings.touchMouse) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val ev = awaitPointerEvent()
                                val pan = ev.calculatePan()
                                if (pan != Offset.Zero) {
                                    mapper.drag(pan.x, pan.y, ev.changes.count { it.pressed })
                                    ev.changes.forEach { it.consume() }
                                }
                            } while (ev.changes.any { it.pressed })
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                Text(program?.name ?: "", color = Color.White, style = MaterialTheme.typography.titleLarge)
                Text(phaseLabel(st.phase), color = Color(0xFF9CC4EE), style = MaterialTheme.typography.titleMedium)
                if (st.message.isNotBlank()) Text(st.message, color = Color.White, textAlign = TextAlign.Center)
                st.exitCode?.let { Text(stringResource(R.string.session_exit_code, it), color = Color.White) }
                if (st.phase == SessionPhase.RUNNING) {
                    Text(
                        stringResource(R.string.session_display_unavailable), color = Color(0xFFFFB74D),
                        textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall
                    )
                }
                Text(stringResource(R.string.session_input_events, events), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
        }

        if (controls) {
            Card(Modifier.align(Alignment.TopCenter).padding(12.dp).fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onExit) { Text(stringResource(R.string.session_back)) }
                        OutlinedButton(
                            enabled = st.phase == SessionPhase.RUNNING || st.phase == SessionPhase.PREPARING,
                            onClick = { vm.stopProgram(id) }
                        ) { Text(stringResource(R.string.session_stop)) }
                        OutlinedButton(
                            enabled = st.phase != SessionPhase.PREPARING,
                            onClick = { vm.restartProgram(id) }
                        ) { Text(stringResource(R.string.session_restart)) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { showLog = !showLog }) { Text(stringResource(R.string.session_log)) }
                        TextButton(onClick = { controls = false }) { Text(stringResource(R.string.session_hide_controls)) }
                    }
                    if (showLog) {
                        Text(
                            if (log.isBlank()) "-" else log,
                            fontFamily = FontFamily.Monospace, fontSize = 10.sp,
                            modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).verticalScroll(rememberScrollState())
                        )
                    }
                }
            }
        } else {
            TextButton(onClick = { controls = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)) {
                Text(stringResource(R.string.session_controls), color = Color.White)
            }
        }
    }
}
