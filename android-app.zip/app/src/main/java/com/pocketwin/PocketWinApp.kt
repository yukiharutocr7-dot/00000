package com.pocketwin

import android.app.Application
import androidx.room.Room
import com.pocketwin.container.ContainerManager
import com.pocketwin.core.AppPaths
import com.pocketwin.core.SettingsStore
import com.pocketwin.data.AppDatabase
import com.pocketwin.device.DeviceCapabilityManager
import com.pocketwin.diagnostics.PwLog
import com.pocketwin.process.NativeBridge
import com.pocketwin.process.RuntimeProcessManager
import com.pocketwin.program.ProgramImporter
import com.pocketwin.program.ProgramRunner
import com.pocketwin.runtime.RuntimeInstaller
import com.pocketwin.runtime.RuntimeManager
import com.pocketwin.session.DisplayBackend
import com.pocketwin.session.UnavailableDisplayBackend
import com.pocketwin.session.WindowSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Simple service locator. One instance per process. */
class Graph(app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val paths = AppPaths(app).also { it.ensure() }
    val settings = SettingsStore(app)
    val db: AppDatabase = Room.databaseBuilder(app, AppDatabase::class.java, "pocketwin.db").build()
    val device = DeviceCapabilityManager(app, paths)
    val installer = RuntimeInstaller(paths)
    val runtime = RuntimeManager(paths, settings, device, installer)
    val processes = RuntimeProcessManager(scope)
    val sessions = WindowSessionManager()
    val display: DisplayBackend = UnavailableDisplayBackend
    val containers = ContainerManager(paths, db.containerDao(), db.programDao(), runtime, processes)
    val importer = ProgramImporter(app, paths, db.programDao(), settings)
    val runner = ProgramRunner(paths, db.programDao(), containers, runtime, processes, sessions, display, settings, scope)
}

class PocketWinApp : Application() {
    lateinit var graph: Graph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = Graph(this)
        PwLog.init(graph.paths.logs)
        PwLog.i("App", "PocketWin started; native=${NativeBridge.loaded}")
    }
}
