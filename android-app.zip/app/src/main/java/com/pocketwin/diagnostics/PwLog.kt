package com.pocketwin.diagnostics

import android.util.Log
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** File logger. Logs contain no personal data: only component names, paths inside app storage and error text. */
object PwLog {
    private var file: File? = null
    private const val MAX_BYTES = 1_000_000L

    fun init(dir: File) {
        dir.mkdirs()
        file = File(dir, "app.log")
    }

    fun logFile(): File? = file

    @Synchronized
    private fun write(level: String, tag: String, msg: String, t: Throwable?) {
        val f = file ?: return
        try {
            if (f.length() > MAX_BYTES) {
                val old = File(f.parentFile, "app.log.1")
                old.delete()
                f.renameTo(old)
            }
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
            f.appendText("$ts $level/$tag: $msg\n")
            if (t != null) f.appendText(Log.getStackTraceString(t) + "\n")
        } catch (e: Exception) {
        }
    }

    fun i(tag: String, msg: String) {
        Log.i("PocketWin/$tag", msg)
        write("I", tag, msg, null)
    }

    fun w(tag: String, msg: String, t: Throwable? = null) {
        Log.w("PocketWin/$tag", msg, t)
        write("W", tag, msg, t)
    }

    fun e(tag: String, msg: String, t: Throwable? = null) {
        Log.e("PocketWin/$tag", msg, t)
        write("E", tag, msg, t)
    }

    fun tail(f: File?, maxBytes: Int = 8192): String {
        if (f == null || !f.exists()) return ""
        return try {
            RandomAccessFile(f, "r").use { raf ->
                val len = raf.length()
                val start = if (len > maxBytes) len - maxBytes else 0L
                raf.seek(start)
                val buf = ByteArray((len - start).toInt())
                raf.readFully(buf)
                String(buf, Charsets.UTF_8)
            }
        } catch (e: Exception) {
            ""
        }
    }
}
