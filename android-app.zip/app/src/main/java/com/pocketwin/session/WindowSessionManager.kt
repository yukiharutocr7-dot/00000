package com.pocketwin.session

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SessionPhase { IDLE, PREPARING, RUNNING, EXITED, CRASHED, FAILED }

data class SessionState(
    val programId: String,
    val phase: SessionPhase,
    val message: String = "",
    val pid: Int = -1,
    val exitCode: Int? = null
)

class WindowSessionManager {
    private val _sessions = MutableStateFlow<Map<String, SessionState>>(emptyMap())
    val sessions: StateFlow<Map<String, SessionState>> = _sessions.asStateFlow()

    fun update(s: SessionState) {
        _sessions.value = _sessions.value + (s.programId to s)
    }

    fun get(id: String): SessionState = _sessions.value[id] ?: SessionState(id, SessionPhase.IDLE)
}

/**
 * Where Wine windows would be rendered. Wine needs an X server; none is implemented yet,
 * so the only backend is UnavailableDisplayBackend and GUI launches are refused honestly.
 */
interface DisplayBackend {
    val name: String
    val available: Boolean
    val unavailableReason: String

    /** Value for the DISPLAY environment variable, or null if there is no display. */
    fun displayEnv(): String?
}

object UnavailableDisplayBackend : DisplayBackend {
    override val name = "none"
    override val available = false
    override val unavailableReason = "No X server / renderer is integrated in this build"
    override fun displayEnv(): String? = null
}
