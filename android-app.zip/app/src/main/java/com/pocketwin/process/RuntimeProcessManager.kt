package com.pocketwin.process

import android.os.SystemClock
import com.pocketwin.core.OpResult
import com.pocketwin.diagnostics.PwLog
import com.pocketwin.runtime.LaunchPlan
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/** Tracks native child processes by key (program id or "init-<container>"). */
class RuntimeProcessManager(private val scope: CoroutineScope) {

    private class Managed(val key: String, val pid: Int, val startedAt: Long, val onExit: (Int) -> Unit)

    private val procs = ConcurrentHashMap<String, Managed>()
    private val lock = Any()
    private var monitor: Job? = null
    private val _active = MutableStateFlow<Set<String>>(emptySet())
    val active: StateFlow<Set<String>> = _active.asStateFlow()

    fun isRunning(key: String): Boolean = procs.containsKey(key)

    fun pidOf(key: String): Int? = procs[key]?.pid

    fun start(key: String, plan: LaunchPlan, onExit: (Int) -> Unit): OpResult<Int> {
        if (!NativeBridge.loaded) return OpResult.failed("Native bridge library could not be loaded")
        if (procs.containsKey(key)) return OpResult.failed("Process already running: $key")
        val pid = NativeBridge.nativeSpawn(
            plan.argv.toTypedArray(), plan.env.toTypedArray(), plan.cwd, plan.logPath
        )
        if (pid <= 0) return OpResult.failed("Spawn failed (errno ${-pid})")
        synchronized(lock) {
            procs[key] = Managed(key, pid, SystemClock.elapsedRealtime(), onExit)
            _active.value = procs.keys.toSet()
            if (monitor == null) monitor = scope.launch { monitorLoop() }
        }
        PwLog.i("Process", "started $key pid=$pid")
        return OpResult.success(pid)
    }

    private suspend fun monitorLoop() {
        while (true) {
            delay(500)
            for (m in procs.values.toList()) {
                val code = NativeBridge.nativePoll(m.pid)
                if (code == NativeBridge.RUNNING) continue
                procs.remove(m.key)
                synchronized(lock) { _active.value = procs.keys.toSet() }
                NativeBridge.nativeKill(m.pid, NativeBridge.SIGKILL) // remove stragglers (wineserver)
                val exit = if (code == NativeBridge.LOST) -1 else code
                PwLog.i("Process", "exited ${m.key} code=$exit")
                try {
                    m.onExit(exit)
                } catch (t: Throwable) {
                    PwLog.e("Process", "onExit handler failed", t)
                }
            }
            synchronized(lock) {
                if (procs.isEmpty()) {
                    monitor = null
                    return
                }
            }
        }
    }

    /** SIGTERM to the process group, SIGKILL after the grace period. Returns true when the process is gone. */
    suspend fun stop(key: String, graceMs: Long = 3000): Boolean {
        val m = procs[key] ?: return true
        NativeBridge.nativeKill(m.pid, NativeBridge.SIGTERM)
        val deadline = SystemClock.elapsedRealtime() + graceMs
        while (procs.containsKey(key) && SystemClock.elapsedRealtime() < deadline) delay(100)
        if (procs.containsKey(key)) {
            NativeBridge.nativeKill(m.pid, NativeBridge.SIGKILL)
            delay(600)
        }
        return !procs.containsKey(key)
    }
}
