package com.pocketwin.process

import com.pocketwin.diagnostics.PwLog

object NativeBridge {
    const val RUNNING = -1000
    const val LOST = -1001
    const val SIGTERM = 15
    const val SIGKILL = 9

    val loaded: Boolean = try {
        System.loadLibrary("pocketwin_native")
        true
    } catch (t: Throwable) {
        false
    }

    external fun nativeVersion(): String
    external fun nativeSpawn(argv: Array<String>, envp: Array<String>, cwd: String, logPath: String): Int
    external fun nativePoll(pid: Int): Int
    external fun nativeKill(pid: Int, sig: Int): Boolean

    fun version(): String? = if (loaded) {
        try {
            nativeVersion()
        } catch (t: Throwable) {
            PwLog.w("Native", "version failed", t)
            null
        }
    } else null
}
