package com.pocketwin.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.pocketwin.core.CompatState
import com.pocketwin.core.ContainerState
import com.pocketwin.core.PeArch
import com.pocketwin.core.ProgramKind
import com.pocketwin.core.ProgramLocation

@Entity(tableName = "programs")
data class ProgramEntity(
    @PrimaryKey val id: String,
    val name: String,
    val fileName: String,
    val kind: String = ProgramKind.EXE.name,
    val location: String = ProgramLocation.IMPORTED.name,
    /** Host directory: the program folder (IMPORTED) or the Wine prefix directory (PREFIX). */
    val baseDir: String,
    /** Executable path relative to baseDir, using "/" separators. */
    val exeRelPath: String,
    val arch: String = PeArch.UNKNOWN.name,
    val isDotNet: Boolean = false,
    val containerId: String,
    val graphicsMode: String = "balanced",
    val resolution: String = "1280x720",
    /** KEY=VALUE per line. */
    val envVars: String = "",
    val args: String = "",
    val trusted: Boolean = false,
    val favorite: Boolean = false,
    val addedAt: Long = 0L,
    val lastRunAt: Long = 0L,
    val lastResult: String = "",
    val compat: String = CompatState.UNTESTED.name,
    val dependencies: String = ""
)

@Entity(tableName = "containers")
data class ContainerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
    val state: String = ContainerState.CREATED.name,
    val wineVersion: String = "",
    val initialized: Boolean = false
)
