package com.pocketwin.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgramDao {
    @Query("SELECT * FROM programs ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<ProgramEntity>>

    @Query("SELECT * FROM programs WHERE id = :id")
    suspend fun get(id: String): ProgramEntity?

    @Query("SELECT * FROM programs WHERE containerId = :containerId")
    suspend fun byContainer(containerId: String): List<ProgramEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: ProgramEntity)

    @Query("DELETE FROM programs WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface ContainerDao {
    @Query("SELECT * FROM containers ORDER BY createdAt")
    fun observeAll(): Flow<List<ContainerEntity>>

    @Query("SELECT * FROM containers WHERE id = :id")
    suspend fun get(id: String): ContainerEntity?

    @Query("SELECT COUNT(*) FROM containers")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(c: ContainerEntity)

    @Query("DELETE FROM containers WHERE id = :id")
    suspend fun delete(id: String)
}

@Database(entities = [ProgramEntity::class, ContainerEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun programDao(): ProgramDao
    abstract fun containerDao(): ContainerDao
}
