package com.pocketwin.container

import com.pocketwin.core.AppPaths
import com.pocketwin.core.ContainerState
import com.pocketwin.core.FileUtil
import com.pocketwin.core.OpResult
import com.pocketwin.core.OpStatus
import com.pocketwin.data.ContainerDao
import com.pocketwin.data.ContainerEntity
import com.pocketwin.data.ProgramDao
import com.pocketwin.diagnostics.PwLog
import com.pocketwin.process.RuntimeProcessManager
import com.pocketwin.runtime.LaunchPlan
import com.pocketwin.runtime.LaunchPlanBuilder
import com.pocketwin.runtime.RuntimeManager
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException

data class ContainerStatus(
    val entity: ContainerEntity,
    val sizeBytes: Long,
    val programCount: Int,
    val running: Boolean
)

class ContainerManager(
    private val paths: AppPaths,
    private val containerDao: ContainerDao,
    private val programDao: ProgramDao,
    private val runtime: RuntimeManager,
    private val processes: RuntimeProcessManager
) {
    suspend fun get(id: String): ContainerEntity? = containerDao.get(id)

    suspend fun ensureDefaultContainer() {
        if (containerDao.count() == 0) createContainer("Default")
    }

    suspend fun createContainer(name: String): OpResult<ContainerEntity> = withContext(Dispatchers.IO) {
        val clean = name.trim()
        if (clean.isEmpty()) return@withContext OpResult.failed<ContainerEntity>("Container name is empty")
        val id = UUID.randomUUID().toString()
        paths.prefixDir(id).mkdirs()
        paths.containerTmp(id).mkdirs()
        val e = ContainerEntity(
            id = id, name = clean, createdAt = System.currentTimeMillis(),
            state = ContainerState.CREATED.name, wineVersion = runtime.installedWineVersion().orEmpty()
        )
        containerDao.upsert(e)
        OpResult.success(e, "Container created")
    }

    suspend fun configureContainer(id: String, newName: String): OpResult<ContainerEntity> {
        val e = containerDao.get(id) ?: return OpResult.failed("Container not found")
        val clean = newName.trim()
        if (clean.isEmpty()) return OpResult.failed("Container name is empty")
        val n = e.copy(name = clean)
        containerDao.upsert(n)
        return OpResult.success(n)
    }

    private suspend fun isBusy(id: String): Boolean =
        processes.isRunning("init-$id") || programDao.byContainer(id).any { processes.isRunning(it.id) }

    suspend fun cloneContainer(id: String, newName: String): OpResult<ContainerEntity> = withContext(Dispatchers.IO) {
        val e = containerDao.get(id) ?: return@withContext OpResult.failed<ContainerEntity>("Container not found")
        if (isBusy(id)) return@withContext OpResult.failed<ContainerEntity>("Stop running programs first")
        val clean = newName.trim()
        if (clean.isEmpty()) return@withContext OpResult.failed<ContainerEntity>("Container name is empty")
        val newId = UUID.randomUUID().toString()
        val dst = paths.containerDir(newId)
        try {
            dst.mkdirs()
            FileUtil.copyTree(paths.containerDir(id), dst, setOf("tmp"))
            paths.containerTmp(newId).mkdirs()
            val n = e.copy(id = newId, name = clean, createdAt = System.currentTimeMillis())
            containerDao.upsert(n)
            OpResult.success(n, "Container cloned")
        } catch (t: Exception) {
            FileUtil.deleteTree(dst)
            OpResult.failed<ContainerEntity>("Clone failed: ${t.message}")
        }
    }

    suspend fun resetContainer(id: String): OpResult<Unit> = withContext(Dispatchers.IO) {
        val e = containerDao.get(id) ?: return@withContext OpResult.failed<Unit>("Container not found")
        if (isBusy(id)) return@withContext OpResult.failed<Unit>("Stop running programs first")
        FileUtil.deleteTree(paths.prefixDir(id))
        FileUtil.deleteTree(paths.containerTmp(id))
        paths.prefixDir(id).mkdirs()
        paths.containerTmp(id).mkdirs()
        containerDao.upsert(e.copy(initialized = false, state = ContainerState.CREATED.name))
        OpResult.success(Unit, "Container reset")
    }

    suspend fun deleteContainer(id: String): OpResult<Unit> = withContext(Dispatchers.IO) {
        containerDao.get(id) ?: return@withContext OpResult.failed<Unit>("Container not found")
        if (isBusy(id)) return@withContext OpResult.failed<Unit>("Stop running programs first")
        val linked = programDao.byContainer(id).size
        if (linked > 0) return@withContext OpResult.failed<Unit>("$linked program(s) still use this container")
        FileUtil.deleteTree(paths.containerDir(id))
        containerDao.delete(id)
        OpResult.success(Unit, "Container deleted")
    }

    suspend fun getContainerStatus(id: String): OpResult<ContainerStatus> = withContext(Dispatchers.IO) {
        val e = containerDao.get(id) ?: return@withContext OpResult.failed<ContainerStatus>("Container not found")
        val progs = programDao.byContainer(id)
        OpResult.success(
            ContainerStatus(e, FileUtil.sizeOf(paths.containerDir(id)), progs.size, isBusy(id))
        )
    }

    /** Creates the Wine prefix with wineboot. Success only if the prefix files really exist afterwards. */
    suspend fun ensureInitialized(id: String, onStatus: (String) -> Unit = {}): OpResult<Unit> =
        withContext(Dispatchers.IO) {
            val e = containerDao.get(id) ?: return@withContext OpResult.failed<Unit>("Container not found")
            val reg = File(paths.prefixDir(id), "system.reg")
            if (e.initialized && reg.exists()) return@withContext OpResult.success(Unit)
            val (rt, missing) = runtime.resolve()
            if (rt == null) return@withContext OpResult.notReady<Unit>("Runtime not ready: " + missing.joinToString("; "))
            onStatus("Initializing Wine prefix (first run, can take several minutes)")
            val plan = LaunchPlanBuilder.build(
                rt = rt,
                prefixDir = paths.prefixDir(id),
                containerTmp = paths.containerTmp(id),
                prootTmp = File(paths.tmp, "proot"),
                programDir = null,
                cwdGuest = "/pocketwin/prefix",
                wineArgv = listOf("wineboot", "-u"),
                userEnv = emptyMap(),
                display = null,
                logFile = File(paths.containerDir(id), "init.log")
            )
            val r = runAndWait("init-$id", plan, 15 * 60_000L)
            if (!r.ok) return@withContext OpResult.failed<Unit>(r.message)
            if (!reg.exists()) {
                return@withContext OpResult.failed<Unit>(
                    "wineboot exited with code ${r.value} but no prefix was created (see init.log in the container folder)"
                )
            }
            containerDao.upsert(
                e.copy(initialized = true, state = ContainerState.READY.name, wineVersion = runtime.installedWineVersion().orEmpty())
            )
            PwLog.i("Container", "initialized $id")
            OpResult.success(Unit, "Prefix created")
        }

    private suspend fun runAndWait(key: String, plan: LaunchPlan, timeoutMs: Long): OpResult<Int> {
        val done = CompletableDeferred<Int>()
        val started = processes.start(key, plan) { done.complete(it) }
        if (!started.ok) return OpResult(started.status, started.message)
        try {
            val code = withTimeoutOrNull(timeoutMs) { done.await() }
            if (code == null) {
                processes.stop(key)
                return OpResult.failed("Timed out after ${timeoutMs / 60000} minutes")
            }
            return if (code == 0) OpResult.success(code) else OpResult(OpStatus.FAILED, "Exited with code $code", code)
        } catch (e: CancellationException) {
            withContext(NonCancellable) { processes.stop(key) }
            throw e
        }
    }

    /** Lists .exe files under Program Files of the prefix (relative to the prefix directory). */
    suspend fun scanInstalledExecutables(id: String): List<String> = withContext(Dispatchers.IO) {
        val prefix = paths.prefixDir(id)
        val out = ArrayList<String>()
        for (top in listOf("drive_c/Program Files", "drive_c/Program Files (x86)")) {
            scanDir(prefix, File(prefix, top), 0, out)
        }
        out.sort()
        out
    }

    private fun scanDir(prefix: File, dir: File, depth: Int, out: MutableList<String>) {
        if (depth > 4 || out.size >= 200) return
        val children = dir.listFiles() ?: return
        for (c in children) {
            if (java.nio.file.Files.isSymbolicLink(c.toPath())) continue
            if (c.isDirectory) {
                scanDir(prefix, c, depth + 1, out)
            } else if (c.name.lowercase().endsWith(".exe") && !c.name.lowercase().contains("unins")) {
                out.add(c.relativeTo(prefix).path.replace(File.separatorChar, '/'))
            }
        }
    }
}
