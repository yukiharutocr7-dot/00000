package com.pocketwin.runtime

import com.pocketwin.core.RuntimeState
import org.json.JSONObject

data class RuntimeComponent(
    val id: String,
    val name: String,
    val role: String,
    val version: String,
    val url: String,
    val sha256: String,
    val sizeBytes: Long,
    val license: String,
    val sourceUrl: String,
    val archive: String,
    val installDir: String
)

data class InstalledInfo(
    val id: String,
    val name: String,
    val role: String,
    val version: String,
    val sha256: String,
    val installDir: String,
    val license: String,
    val installedAt: Long
)

data class RuntimeStatus(
    val state: RuntimeState,
    val missing: List<String>,
    val message: String
)

data class ComponentStatus(
    val component: RuntimeComponent,
    val installedVersion: String?,
    val sizeOnDisk: Long,
    val healthy: Boolean
)

object ManifestParser {
    private val ID = Regex("^[a-z0-9][a-z0-9_.-]{0,63}$")
    private val SHA = Regex("^[0-9a-fA-F]{64}$")
    val ARCHIVES = setOf("zip", "tar", "tar.gz", "tar.xz", "raw")
    val ROLES = listOf("rootfs", "proot", "box64", "wine", "graphics", "dependency")

    fun parse(text: String): List<RuntimeComponent> {
        val root = JSONObject(text)
        require(root.optInt("schema", 0) == 1) { "Unsupported manifest schema" }
        val arr = root.getJSONArray("components")
        val out = ArrayList<RuntimeComponent>()
        val seen = HashSet<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getString("id")
            val role = o.getString("role")
            val url = o.getString("url")
            val sha = o.getString("sha256")
            val archive = o.optString("archive", "tar.xz")
            val installDir = o.getString("installDir")
            val version = o.getString("version")
            val license = o.optString("license", "")
            require(ID.matches(id)) { "Invalid component id: $id" }
            require(seen.add(id)) { "Duplicate component id: $id" }
            require(ROLES.contains(role)) { "Invalid role for $id: $role" }
            require(url.startsWith("https://")) { "Component $id must use an https URL" }
            require(SHA.matches(sha)) { "Component $id needs a 64-hex SHA-256" }
            require(ARCHIVES.contains(archive)) { "Unsupported archive type for $id: $archive" }
            require(version.isNotBlank()) { "Component $id has no version" }
            require(license.isNotBlank()) { "Component $id must declare its license" }
            require(
                installDir.isNotBlank() && !installDir.startsWith("/") &&
                    !installDir.contains("..") && !installDir.contains("\\")
            ) { "Unsafe installDir for $id" }
            out.add(
                RuntimeComponent(
                    id = id,
                    name = o.optString("name", id),
                    role = role,
                    version = version,
                    url = url,
                    sha256 = sha.lowercase(),
                    sizeBytes = o.optLong("sizeBytes", 0L).coerceAtLeast(0L),
                    license = license,
                    sourceUrl = o.optString("sourceUrl", ""),
                    archive = archive,
                    installDir = installDir.trimEnd('/')
                )
            )
        }
        return out
    }
}
