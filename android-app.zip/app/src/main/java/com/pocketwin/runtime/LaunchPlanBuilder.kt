package com.pocketwin.runtime

import java.io.File

data class LaunchPlan(
    val argv: List<String>,
    val env: List<String>,
    val cwd: String,
    val logPath: String
)

/** Builds: proot -r rootfs ... box64 wine64 <args>. Pure function of its inputs, unit-tested. */
object LaunchPlanBuilder {
    const val GUEST_PREFIX = "/pocketwin/prefix"
    const val GUEST_PROGRAM = "/pocketwin/program"

    fun build(
        rt: ResolvedRuntime,
        prefixDir: File,
        containerTmp: File,
        prootTmp: File,
        programDir: File?,
        cwdGuest: String,
        wineArgv: List<String>,
        userEnv: Map<String, String>,
        display: String?,
        logFile: File
    ): LaunchPlan {
        val argv = ArrayList<String>()
        argv.add(rt.proot.absolutePath)
        argv.addAll(listOf("-r", rt.rootfs.absolutePath, "-0", "--link2symlink", "--kill-on-exit"))
        argv.addAll(listOf("-b", "/dev", "-b", "/proc", "-b", "/sys"))
        argv.addAll(listOf("-b", "${prefixDir.absolutePath}:$GUEST_PREFIX"))
        argv.addAll(listOf("-b", "${containerTmp.absolutePath}:/tmp"))
        if (programDir != null) argv.addAll(listOf("-b", "${programDir.absolutePath}:$GUEST_PROGRAM"))
        argv.addAll(listOf("-w", cwdGuest, rt.box64Guest, rt.wineGuest))
        argv.addAll(wineArgv)

        val env = LinkedHashMap<String, String>()
        env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/opt/wine/bin"
        env["HOME"] = "/root"
        env["USER"] = "root"
        env["TMPDIR"] = "/tmp"
        env["LANG"] = "en_US.UTF-8"
        env["WINEPREFIX"] = GUEST_PREFIX
        env["WINEDEBUG"] = "-all"
        env["WINEDLLOVERRIDES"] = "mscoree,mshtml="
        env["BOX64_NOBANNER"] = "1"
        env["BOX64_LOG"] = "0"
        if (display != null) env["DISPLAY"] = display
        env.putAll(RuntimeLayout.readRootfsEnv(rt.rootfs))
        env.putAll(userEnv)
        // Host-side proot settings last so they cannot be overridden by program environment.
        env["PROOT_TMP_DIR"] = prootTmp.absolutePath
        env["PROOT_NO_SECCOMP"] = "1"
        rt.loader?.let { env["PROOT_LOADER"] = it.absolutePath }
        rt.loader32?.let { env["PROOT_LOADER_32"] = it.absolutePath }

        prootTmp.mkdirs()
        containerTmp.mkdirs()
        return LaunchPlan(argv, env.map { "${it.key}=${it.value}" }, prootTmp.absolutePath, logFile.absolutePath)
    }
}
