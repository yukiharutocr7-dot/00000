package com.pocketwin.runtime

import com.pocketwin.core.AppPaths
import com.pocketwin.core.FileUtil
import com.pocketwin.core.OpResult
import com.pocketwin.diagnostics.PwLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Paths
import java.security.MessageDigest
import java.util.zip.ZipInputStream
import kotlin.coroutines.cancellation.CancellationException

/** Downloads, verifies (SHA-256) and extracts runtime components. Never installs unverified data. */
class RuntimeInstaller(private val paths: AppPaths) {

    private val registryFile get() = File(paths.runtime, "installed.json")

    @Synchronized
    fun readRegistry(): Map<String, InstalledInfo> {
        val f = registryFile
        if (!f.exists()) return emptyMap()
        return try {
            val comps = JSONObject(f.readText()).getJSONObject("components")
            val out = LinkedHashMap<String, InstalledInfo>()
            for (id in comps.keys()) {
                val o = comps.getJSONObject(id)
                out[id] = InstalledInfo(
                    id = id,
                    name = o.optString("name", id),
                    role = o.optString("role", "dependency"),
                    version = o.optString("version", ""),
                    sha256 = o.optString("sha256", ""),
                    installDir = o.optString("installDir", id),
                    license = o.optString("license", ""),
                    installedAt = o.optLong("installedAt", 0L)
                )
            }
            out
        } catch (t: Exception) {
            PwLog.w("Installer", "registry unreadable", t)
            emptyMap()
        }
    }

    @Synchronized
    private fun writeRegistry(map: Map<String, InstalledInfo>) {
        val comps = JSONObject()
        for ((id, i) in map) {
            comps.put(
                id, JSONObject()
                    .put("name", i.name).put("role", i.role).put("version", i.version)
                    .put("sha256", i.sha256).put("installDir", i.installDir)
                    .put("license", i.license).put("installedAt", i.installedAt)
            )
        }
        paths.runtime.mkdirs()
        val tmp = File(paths.runtime, "installed.json.tmp")
        tmp.writeText(JSONObject().put("components", comps).toString(2))
        if (!tmp.renameTo(registryFile)) throw IOException("Cannot update registry")
    }

    suspend fun fetchManifest(url: String): OpResult<String> = withContext(Dispatchers.IO) {
        if (!url.startsWith("https://")) return@withContext OpResult.failed<String>("Manifest URL must start with https://")
        try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.instanceFollowRedirects = true
            if (conn.responseCode != 200) {
                return@withContext OpResult.failed<String>("Manifest download failed: HTTP ${conn.responseCode}")
            }
            val bytes = conn.inputStream.use { it.readNBytesLimited(1_000_000) }
            OpResult.success(String(bytes, Charsets.UTF_8))
        } catch (e: CancellationException) {
            throw e
        } catch (t: Exception) {
            OpResult.failed<String>("Manifest download failed: ${t.message}")
        }
    }

    private fun InputStream.readNBytesLimited(limit: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (true) {
            val n = read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            if (out.size() > limit) throw IOException("Manifest too large")
        }
        return out.toByteArray()
    }

    suspend fun install(c: RuntimeComponent, onProgress: (Long, Long) -> Unit): OpResult<Unit> =
        withContext(Dispatchers.IO) {
            val free = paths.root.usableSpace
            if (c.sizeBytes > 0 && free < c.sizeBytes * 3) {
                return@withContext OpResult.failed<Unit>(
                    "Not enough storage: need about ${c.sizeBytes * 3 / 1048576} MB, free ${free / 1048576} MB"
                )
            }
            paths.downloads.mkdirs()
            val part = File(paths.downloads, "${c.id}-${c.version}.part")
            val staging = File(paths.runtime, ".tmp-${c.id}")
            try {
                var lastError = ""
                var ok = false
                for (attempt in 1..3) {
                    try {
                        val digest = download(c.url, part, c.sizeBytes, onProgress)
                        if (!digest.equals(c.sha256, ignoreCase = true)) {
                            part.delete()
                            return@withContext OpResult.failed<Unit>(
                                "SHA-256 mismatch for ${c.id}: expected ${c.sha256}, got $digest. File discarded."
                            )
                        }
                        ok = true
                        break
                    } catch (e: CancellationException) {
                        throw e
                    } catch (t: IOException) {
                        lastError = t.message ?: t.javaClass.simpleName
                        PwLog.w("Installer", "download attempt $attempt failed: $lastError")
                        delay(1000L * attempt)
                    }
                }
                if (!ok) return@withContext OpResult.failed<Unit>("Download failed after 3 attempts: $lastError")

                FileUtil.deleteTree(staging)
                staging.mkdirs()
                extract(part, c, staging)

                val target = File(paths.runtime, c.installDir)
                val rtPath = paths.runtime.toPath().normalize()
                if (!target.toPath().normalize().startsWith(rtPath) || target.toPath().normalize() == rtPath) {
                    return@withContext OpResult.failed<Unit>("Unsafe install directory")
                }
                target.parentFile?.mkdirs()
                FileUtil.deleteTree(target)
                if (!staging.renameTo(target)) {
                    return@withContext OpResult.failed<Unit>("Cannot move component into place")
                }
                val reg = LinkedHashMap(readRegistry())
                // Components installed inside this directory are gone now.
                reg.entries.removeAll { it.value.installDir.startsWith(c.installDir + "/") }
                reg[c.id] = InstalledInfo(
                    c.id, c.name, c.role, c.version, c.sha256, c.installDir, c.license, System.currentTimeMillis()
                )
                writeRegistry(reg)
                PwLog.i("Installer", "installed ${c.id} ${c.version}")
                OpResult.success(Unit, "Installed ${c.id} ${c.version}")
            } catch (e: CancellationException) {
                throw e
            } catch (t: Exception) {
                PwLog.e("Installer", "install ${c.id} failed", t)
                OpResult.failed<Unit>("Install failed: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                part.delete()
                FileUtil.deleteTree(staging)
            }
        }

    fun uninstall(id: String): OpResult<Unit> {
        val reg = LinkedHashMap(readRegistry())
        val info = reg[id] ?: return OpResult.failed("Component not installed: $id")
        FileUtil.deleteTree(File(paths.runtime, info.installDir))
        reg.entries.removeAll { it.key == id || it.value.installDir.startsWith(info.installDir + "/") }
        writeRegistry(reg)
        return OpResult.success(Unit, "Removed $id")
    }

    private suspend fun download(url: String, dest: File, expected: Long, onProgress: (Long, Long) -> Unit): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
        val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else expected
        val md = MessageDigest.getInstance("SHA-256")
        var done = 0L
        var lastReport = 0L
        conn.inputStream.use { input ->
            dest.outputStream().use { out ->
                val buf = ByteArray(65536)
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    md.update(buf, 0, n)
                    done += n
                    if (done - lastReport >= 262144) {
                        lastReport = done
                        onProgress(done, total)
                    }
                }
            }
        }
        onProgress(done, if (total > 0) total else done)
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun safeChild(dest: File, name: String): File {
        val out = File(dest, name)
        val d = dest.toPath().normalize()
        val p = out.toPath().normalize()
        if (!p.startsWith(d) || p == d) throw IOException("Unsafe archive entry: $name")
        return out
    }

    private fun cleanName(n: String): String {
        var s = n
        while (s.startsWith("./")) s = s.substring(2)
        return s.trimStart('/')
    }

    private fun extract(archive: File, c: RuntimeComponent, dest: File) {
        when (c.archive) {
            "raw" -> {
                val out = File(dest, c.id)
                archive.copyTo(out, overwrite = true)
                out.setExecutable(true, false)
            }
            "zip" -> ZipInputStream(BufferedInputStream(FileInputStream(archive))).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val name = cleanName(e.name)
                    if (name.isEmpty()) continue
                    val out = safeChild(dest, name)
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zin.copyTo(it) }
                        if (name.contains("bin/")) out.setExecutable(true, false)
                    }
                }
            }
            else -> {
                val raw = BufferedInputStream(FileInputStream(archive))
                val stream: InputStream = when (c.archive) {
                    "tar.gz" -> GzipCompressorInputStream(raw)
                    "tar.xz" -> XZCompressorInputStream(raw)
                    else -> raw
                }
                TarArchiveInputStream(stream).use { tar ->
                    while (true) {
                        val e = tar.nextTarEntry ?: break
                        val name = cleanName(e.name)
                        if (name.isEmpty()) continue
                        val out = safeChild(dest, name)
                        when {
                            e.isDirectory -> out.mkdirs()
                            e.isSymbolicLink -> {
                                out.parentFile?.mkdirs()
                                Files.deleteIfExists(out.toPath())
                                Files.createSymbolicLink(out.toPath(), Paths.get(e.linkName))
                            }
                            e.isLink -> {
                                val srcLink = File(dest, cleanName(e.linkName))
                                if (srcLink.exists()) {
                                    out.parentFile?.mkdirs()
                                    srcLink.copyTo(out, overwrite = true)
                                    out.setExecutable(srcLink.canExecute(), false)
                                }
                            }
                            e.isFile -> {
                                out.parentFile?.mkdirs()
                                if (Files.isSymbolicLink(out.toPath())) Files.delete(out.toPath())
                                out.outputStream().use { tar.copyTo(it) }
                                if ((e.mode and 0x49) != 0) out.setExecutable(true, false)
                            }
                            else -> { /* device nodes, fifos: skipped on purpose */ }
                        }
                    }
                }
            }
        }
    }

    fun exists(path: File): Boolean = Files.exists(path.toPath(), LinkOption.NOFOLLOW_LINKS)
}
