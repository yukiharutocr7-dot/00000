package com.pocketwin.runtime

import com.pocketwin.core.AppPaths
import com.pocketwin.core.TextUtil
import java.io.File
import java.nio.file.Files
import java.nio.file.LinkOption

data class ResolvedRuntime(
    val rootfs: File,
    val proot: File,
    val loader: File?,
    val loader32: File?,
    /** Path of box64 inside the rootfs. */
    val box64Guest: String,
    /** Path of the wine launcher inside the rootfs. */
    val wineGuest: String
)

/** Fixed layout contract between installed runtime archives and the launcher. */
object RuntimeLayout {
    val BOX64_CANDIDATES = listOf("/usr/local/bin/box64", "/usr/bin/box64", "/opt/box64/box64")
    val WINE_CANDIDATES = listOf("/opt/wine/bin/wine64", "/opt/wine/bin/wine", "/usr/local/bin/wine64")

    private fun existsNoFollow(f: File) = Files.exists(f.toPath(), LinkOption.NOFOLLOW_LINKS)

    fun resolve(paths: AppPaths): Pair<ResolvedRuntime?, List<String>> {
        val missing = ArrayList<String>()
        val rootfs = File(paths.runtime, "rootfs")
        val rootOk = rootfs.isDirectory && (File(rootfs, "usr").exists() || File(rootfs, "bin").exists())
        if (!rootOk) missing.add("rootfs")
        val proot = File(paths.runtime, "proot/proot")
        if (!proot.isFile || !proot.canExecute()) missing.add("proot")
        var box: String? = null
        var wine: String? = null
        if (rootOk) {
            box = BOX64_CANDIDATES.firstOrNull { existsNoFollow(File(rootfs, it.removePrefix("/"))) }
            wine = WINE_CANDIDATES.firstOrNull { existsNoFollow(File(rootfs, it.removePrefix("/"))) }
            if (box == null) missing.add("box64 (inside rootfs)")
            if (wine == null) missing.add("wine (inside rootfs)")
        } else {
            missing.add("box64 (inside rootfs)")
            missing.add("wine (inside rootfs)")
        }
        if (missing.isNotEmpty() || box == null || wine == null) return Pair(null, missing)
        val loader = File(paths.runtime, "proot/loader").takeIf { it.isFile }
        val loader32 = File(paths.runtime, "proot/loader32").takeIf { it.isFile }
        return Pair(ResolvedRuntime(rootfs, proot, loader, loader32, box, wine), emptyList())
    }

    fun readRootfsEnv(rootfs: File): Map<String, String> {
        val f = File(rootfs, "pocketwin-env.conf")
        return if (f.isFile) TextUtil.parseEnv(f.readText()) else emptyMap()
    }
}
