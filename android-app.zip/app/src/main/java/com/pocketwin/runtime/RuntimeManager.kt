package com.pocketwin.runtime

import com.pocketwin.core.AppPaths
import com.pocketwin.core.FileUtil
import com.pocketwin.core.OpResult
import com.pocketwin.core.RuntimeState
import com.pocketwin.core.SettingsStore
import com.pocketwin.device.Blocker
import com.pocketwin.device.DeviceCapabilityManager
import com.pocketwin.diagnostics.PwLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class RuntimeManager(
    private val paths: AppPaths,
    private val settings: SettingsStore,
    private val device: DeviceCapabilityManager,
    private val installer: RuntimeInstaller
) {
    private val manifestCache get() = File(paths.runtime, "manifest.json")

    suspend fun initializeRuntime(): OpResult<RuntimeStatus> = withContext(Dispatchers.IO) {
        paths.ensure()
        val st = computeStatus()
        PwLog.i("Runtime", "initialize: ${st.state} ${st.message}")
        OpResult.success(st, st.message)
    }

    suspend fun getRuntimeStatus(): RuntimeStatus = withContext(Dispatchers.IO) { computeStatus() }

    /** Re-checks installed components on disk. Success only if the runtime is fully usable. */
    suspend fun verifyRuntime(): OpResult<RuntimeStatus> = withContext(Dispatchers.IO) {
        val st = computeStatus()
        val broken = installer.readRegistry().values.filter { !File(paths.runtime, it.installDir).exists() }
        if (broken.isNotEmpty()) {
            return@withContext OpResult(
                com.pocketwin.core.OpStatus.FAILED,
                "Missing on disk: " + broken.joinToString { it.id },
                st
            )
        }
        if (st.state == RuntimeState.READY) OpResult.success(st, "Runtime verified")
        else OpResult(com.pocketwin.core.OpStatus.NOT_READY, st.message, st)
    }

    fun resolve(): Pair<ResolvedRuntime?, List<String>> = RuntimeLayout.resolve(paths)

    fun loadManifest(): List<RuntimeComponent> = try {
        if (manifestCache.exists()) ManifestParser.parse(manifestCache.readText()) else emptyList()
    } catch (t: Exception) {
        PwLog.w("Runtime", "cached manifest invalid", t)
        emptyList()
    }

    private fun computeStatus(): RuntimeStatus {
        val reg = installer.readRegistry()
        val (resolved, missing) = RuntimeLayout.resolve(paths)
        if (resolved != null) return RuntimeStatus(RuntimeState.READY, emptyList(), "All required components are present")
        val state = when {
            reg.isEmpty() && settings.state.value.manifestUrl.isBlank() && loadManifest().isEmpty() ->
                RuntimeState.NOT_CONFIGURED
            reg.isEmpty() -> RuntimeState.NOT_INSTALLED
            else -> RuntimeState.PARTIAL
        }
        return RuntimeStatus(state, missing, "Missing: " + missing.joinToString("; "))
    }

    suspend fun listRuntimeComponents(): List<ComponentStatus> = withContext(Dispatchers.IO) {
        val reg = installer.readRegistry()
        val out = ArrayList<ComponentStatus>()
        val manifest = loadManifest()
        for (c in manifest) {
            val inst = reg[c.id]
            val dir = File(paths.runtime, c.installDir)
            out.add(
                ComponentStatus(c, inst?.version, if (inst != null) FileUtil.sizeOf(dir) else 0L, inst != null && dir.exists())
            )
        }
        for (inst in reg.values) {
            if (manifest.any { it.id == inst.id }) continue
            val dir = File(paths.runtime, inst.installDir)
            val c = RuntimeComponent(
                inst.id, inst.name, inst.role, inst.version, "", inst.sha256, 0L,
                inst.license, "", "tar.xz", inst.installDir
            )
            out.add(ComponentStatus(c, inst.version, FileUtil.sizeOf(dir), dir.exists()))
        }
        out
    }

    fun installedWineVersion(): String? = installer.readRegistry().values.firstOrNull { it.role == "wine" }?.version

    suspend fun fetchManifest(url: String): OpResult<List<RuntimeComponent>> {
        val r = installer.fetchManifest(url)
        val text = r.value
        if (!r.ok || text == null) return OpResult(r.status, r.message)
        return try {
            val list = ManifestParser.parse(text)
            withContext(Dispatchers.IO) {
                paths.runtime.mkdirs()
                manifestCache.writeText(text)
            }
            OpResult.success(list, "Manifest loaded: ${list.size} components")
        } catch (t: Exception) {
            OpResult.failed("Invalid manifest: ${t.message}")
        }
    }

    suspend fun installComponent(c: RuntimeComponent, onProgress: (Long, Long) -> Unit): OpResult<Unit> {
        if (c.url.isBlank()) return OpResult.failed("No download URL for ${c.id}")
        if (device.collect().blockers.contains(Blocker.NO_ARM64)) {
            return OpResult.failed("This device has no arm64-v8a ABI; the runtime cannot be used")
        }
        if (c.installDir.startsWith("rootfs/") && !File(paths.runtime, "rootfs").isDirectory) {
            return OpResult.failed("Install the rootfs component first")
        }
        return installer.install(c, onProgress)
    }

    fun removeComponent(id: String): OpResult<Unit> = installer.uninstall(id)

    /** Fetches the configured manifest and installs every missing or outdated component. */
    suspend fun updateRuntime(onProgress: (String, Long, Long) -> Unit): OpResult<Unit> {
        val url = settings.state.value.manifestUrl.trim()
        if (url.isEmpty()) return OpResult.notReady("Set the manifest URL first")
        val m = fetchManifest(url)
        val list = m.value
        if (!m.ok || list == null) return OpResult(m.status, m.message)
        val reg = installer.readRegistry()
        val ordered = list.sortedBy { ManifestParser.ROLES.indexOf(it.role) }
        var installed = 0
        for (c in ordered) {
            val cur = reg[c.id]
            val dirOk = File(paths.runtime, c.installDir).exists()
            if (cur != null && cur.version == c.version && cur.sha256.equals(c.sha256, true) && dirOk) continue
            val r = installComponent(c) { d, t -> onProgress(c.id, d, t) }
            if (!r.ok) return OpResult.failed("${c.id}: ${r.message}")
            installed++
        }
        return OpResult.success(Unit, if (installed == 0) "Already up to date" else "Installed $installed component(s)")
    }

    fun getRuntimeDiagnostics(): String {
        val d = device.collect()
        val st = computeStatus()
        val reg = installer.readRegistry()
        val sb = StringBuilder()
        sb.appendLine("PocketWin diagnostics")
        sb.appendLine("Android ${d.release} (API ${d.sdk}); ABIs ${d.abis.joinToString()}")
        sb.appendLine("SoC ${d.socModel}; hardware ${d.hardware}")
        sb.appendLine("RAM ${d.ramTotalMb} MB; free storage ${d.storageFreeMb} MB")
        sb.appendLine("Vulkan: ${d.vulkanVersion ?: "not reported"} (level ${d.vulkanLevel ?: "not reported"}); GLES ${d.glEsVersion}")
        sb.appendLine("Blockers: ${if (d.blockers.isEmpty()) "none" else d.blockers.joinToString()}")
        sb.appendLine("Native bridge loaded: ${com.pocketwin.process.NativeBridge.loaded}")
        sb.appendLine("Runtime: ${st.state} - ${st.message}")
        sb.appendLine("Manifest URL set: ${settings.state.value.manifestUrl.isNotBlank()}")
        if (reg.isEmpty()) sb.appendLine("Installed components: none")
        for (i in reg.values) sb.appendLine("  ${i.id} ${i.version} role=${i.role} dir=${i.installDir} sha256=${i.sha256.take(12)}...")
        return sb.toString()
    }
}
