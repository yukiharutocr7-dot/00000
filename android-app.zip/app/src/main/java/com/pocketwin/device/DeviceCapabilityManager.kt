package com.pocketwin.device

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.pocketwin.core.AppPaths

enum class Blocker { NO_ARM64, ANDROID_TOO_OLD, LOW_STORAGE, LOW_RAM }

data class DeviceCapabilities(
    val sdk: Int,
    val release: String,
    val abis: List<String>,
    val ramTotalMb: Long,
    val storageFreeMb: Long,
    /** Null means the device does not report it (unknown), not "unsupported". */
    val vulkanVersion: String?,
    val vulkanLevel: Int?,
    val glEsVersion: String,
    val socModel: String,
    val hardware: String,
    val blockers: List<Blocker>
)

class DeviceCapabilityManager(private val context: Context, private val paths: AppPaths) {

    fun collect(): DeviceCapabilities {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ramMb = mi.totalMem / (1024L * 1024L)
        val freeMb = paths.root.usableSpace / (1024L * 1024L)
        val features = context.packageManager.systemAvailableFeatures
        val vkVer = features?.firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_VERSION }?.version
        val vkLvl = features?.firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL }?.version
        val gl = try {
            am.deviceConfigurationInfo.glEsVersion ?: ""
        } catch (e: Exception) {
            ""
        }
        val soc = if (Build.VERSION.SDK_INT >= 31) {
            "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}"
        } else {
            Build.HARDWARE
        }
        val abis = Build.SUPPORTED_ABIS.toList()
        val blockers = ArrayList<Blocker>()
        if (!abis.contains("arm64-v8a")) blockers.add(Blocker.NO_ARM64)
        if (Build.VERSION.SDK_INT < 26) blockers.add(Blocker.ANDROID_TOO_OLD)
        if (freeMb < MIN_FREE_MB) blockers.add(Blocker.LOW_STORAGE)
        if (ramMb < MIN_RAM_MB) blockers.add(Blocker.LOW_RAM)
        return DeviceCapabilities(
            sdk = Build.VERSION.SDK_INT,
            release = Build.VERSION.RELEASE ?: "",
            abis = abis,
            ramTotalMb = ramMb,
            storageFreeMb = freeMb,
            vulkanVersion = vkVer?.let { decodeVulkan(it) },
            vulkanLevel = vkLvl,
            glEsVersion = gl,
            socModel = soc,
            hardware = Build.HARDWARE ?: "",
            blockers = blockers
        )
    }

    companion object {
        const val MIN_FREE_MB = 2048L
        const val MIN_RAM_MB = 1500L

        fun decodeVulkan(v: Int): String = "${v ushr 22}.${(v ushr 12) and 0x3FF}.${v and 0xFFF}"
    }
}
