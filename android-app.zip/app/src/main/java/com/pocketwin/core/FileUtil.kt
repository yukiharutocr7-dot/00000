package com.pocketwin.core

import java.io.File
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes

/**
 * Symlink-safe file helpers. Wine prefixes contain symlinks (for example dosdevices/z: -> /),
 * so recursive operations must never follow links.
 */
object FileUtil {
    fun deleteTree(f: File) {
        val p = f.toPath()
        if (!Files.exists(p, LinkOption.NOFOLLOW_LINKS)) return
        Files.walkFileTree(p, object : SimpleFileVisitor<Path>() {
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                Files.delete(file)
                return FileVisitResult.CONTINUE
            }

            override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult =
                FileVisitResult.CONTINUE

            override fun postVisitDirectory(dir: Path, exc: IOException?): FileVisitResult {
                try {
                    Files.delete(dir)
                } catch (e: IOException) {
                }
                return FileVisitResult.CONTINUE
            }
        })
    }

    fun sizeOf(f: File): Long {
        val p = f.toPath()
        if (!Files.exists(p, LinkOption.NOFOLLOW_LINKS)) return 0L
        var total = 0L
        Files.walkFileTree(p, object : SimpleFileVisitor<Path>() {
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                if (attrs.isRegularFile) total += attrs.size()
                return FileVisitResult.CONTINUE
            }

            override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult =
                FileVisitResult.CONTINUE
        })
        return total
    }

    fun copyTree(src: File, dst: File, skipTopLevel: Set<String> = emptySet()) {
        val s = src.toPath()
        val d = dst.toPath()
        Files.walkFileTree(s, object : SimpleFileVisitor<Path>() {
            private fun skipped(path: Path): Boolean {
                val rel = s.relativize(path)
                return rel.nameCount > 0 && rel.toString().isNotEmpty() &&
                    skipTopLevel.contains(rel.getName(0).toString())
            }

            override fun preVisitDirectory(dir: Path, attrs: BasicFileAttributes): FileVisitResult {
                if (skipped(dir)) return FileVisitResult.SKIP_SUBTREE
                Files.createDirectories(d.resolve(s.relativize(dir).toString()))
                return FileVisitResult.CONTINUE
            }

            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                if (skipped(file)) return FileVisitResult.CONTINUE
                val target = d.resolve(s.relativize(file).toString())
                if (attrs.isSymbolicLink) {
                    Files.createSymbolicLink(target, Files.readSymbolicLink(file))
                } else {
                    Files.copy(file, target)
                    target.toFile().setExecutable(file.toFile().canExecute())
                }
                return FileVisitResult.CONTINUE
            }
        })
    }
}
