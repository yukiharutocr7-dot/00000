package com.pocketwin.core

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    private fun load(): AppSettings = AppSettings(
        language = prefs.getString("language", "ar") ?: "ar",
        theme = prefs.getString("theme", "system") ?: "system",
        manifestUrl = prefs.getString("manifestUrl", "") ?: "",
        defaultResolution = prefs.getString("defaultResolution", "1280x720") ?: "1280x720",
        performance = prefs.getString("performance", "balanced") ?: "balanced",
        allowHeadless = prefs.getBoolean("allowHeadless", false),
        touchMouse = prefs.getBoolean("touchMouse", true)
    )

    @Synchronized
    fun update(transform: (AppSettings) -> AppSettings) {
        val n = transform(_state.value)
        prefs.edit()
            .putString("language", n.language)
            .putString("theme", n.theme)
            .putString("manifestUrl", n.manifestUrl)
            .putString("defaultResolution", n.defaultResolution)
            .putString("performance", n.performance)
            .putBoolean("allowHeadless", n.allowHeadless)
            .putBoolean("touchMouse", n.touchMouse)
            .apply()
        _state.value = n
    }

    companion object {
        const val PREFS = "pocketwin_settings"

        fun readLanguage(ctx: Context): String =
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("language", "ar") ?: "ar"
    }
}
