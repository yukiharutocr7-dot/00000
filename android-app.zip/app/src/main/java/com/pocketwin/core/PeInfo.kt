package com.pocketwin.core

import java.io.File
import java.io.InputStream

enum class FileKind { PE, OLE_COMPOUND, UNKNOWN }

data class PeInfo(
    val kind: FileKind,
    val arch: PeArch,
    val isDll: Boolean = false,
    val isGui: Boolean? = null,
    val isDotNet: Boolean = false
)

/** Minimal, bounds-checked PE header parser. Reads only the first 64 KiB. */
object PeParser {
    const val HEADER_BYTES = 65536

    fun parse(file: File): PeInfo = file.inputStream().use { parse(it) }

    fun parse(input: InputStream): PeInfo {
        val buf = ByteArray(HEADER_BYTES)
        var read = 0
        while (read < buf.size) {
            val n = input.read(buf, read, buf.size - read)
            if (n < 0) break
            read += n
        }
        return parse(buf.copyOf(read))
    }

    private val OLE_MAGIC = intArrayOf(0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1)

    private fun u16(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun u32(b: ByteArray, o: Int): Int = u16(b, o) or (u16(b, o + 2) shl 16)

    fun parse(b: ByteArray): PeInfo {
        if (b.size >= 8 && OLE_MAGIC.indices.all { (b[it].toInt() and 0xFF) == OLE_MAGIC[it] }) {
            return PeInfo(FileKind.OLE_COMPOUND, PeArch.UNKNOWN)
        }
        val notPe = PeInfo(FileKind.UNKNOWN, PeArch.NOT_PE)
        if (b.size < 0x40 || b[0] != 'M'.code.toByte() || b[1] != 'Z'.code.toByte()) return notPe
        val peOff = u32(b, 0x3C)
        if (peOff < 0 || peOff.toLong() + 24L > b.size.toLong()) return notPe
        if (b[peOff] != 'P'.code.toByte() || b[peOff + 1] != 'E'.code.toByte() ||
            b[peOff + 2].toInt() != 0 || b[peOff + 3].toInt() != 0
        ) return notPe

        val arch = when (u16(b, peOff + 4)) {
            0x014C -> PeArch.X86
            0x8664 -> PeArch.X64
            0xAA64 -> PeArch.ARM64
            0x01C0, 0x01C4 -> PeArch.ARM
            else -> PeArch.UNKNOWN
        }
        val isDll = (u16(b, peOff + 22) and 0x2000) != 0
        val opt = peOff + 24
        var gui: Boolean? = null
        var dotNet = false
        if (opt.toLong() + 70L <= b.size.toLong()) {
            val magic = u16(b, opt)
            val subsystem = u16(b, opt + 68)
            gui = when (subsystem) {
                2 -> true
                3 -> false
                else -> null
            }
            val pe32Plus = magic == 0x20B
            val countOff = opt + if (pe32Plus) 108 else 92
            val dirBase = opt + if (pe32Plus) 112 else 96
            if (countOff.toLong() + 4L <= b.size.toLong() && dirBase.toLong() + 128L <= b.size.toLong()) {
                val count = u32(b, countOff)
                if (count > 14) {
                    val rva = u32(b, dirBase + 14 * 8)
                    val size = u32(b, dirBase + 14 * 8 + 4)
                    dotNet = rva != 0 && size != 0
                }
            }
        }
        return PeInfo(FileKind.PE, arch, isDll, gui, dotNet)
    }
}
