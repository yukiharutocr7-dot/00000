package com.pocketwin.core

enum class OpStatus { SUCCESS, FAILED, NOT_IMPLEMENTED, NOT_READY }

/** Explicit operation result. Never report success for work that did not happen. */
data class OpResult<out T>(
    val status: OpStatus,
    val message: String = "",
    val value: T? = null
) {
    val ok: Boolean get() = status == OpStatus.SUCCESS

    companion object {
        fun <T> success(value: T? = null, message: String = ""): OpResult<T> =
            OpResult(OpStatus.SUCCESS, message, value)

        fun <T> failed(message: String): OpResult<T> = OpResult(OpStatus.FAILED, message)

        fun <T> notImplemented(message: String): OpResult<T> =
            OpResult(OpStatus.NOT_IMPLEMENTED, message)

        fun <T> notReady(message: String): OpResult<T> = OpResult(OpStatus.NOT_READY, message)
    }
}

enum class PeArch { X86, X64, ARM64, ARM, UNKNOWN, NOT_PE }
enum class ProgramKind { EXE, MSI }
enum class ProgramLocation { IMPORTED, PREFIX }
enum class ContainerState { CREATED, READY }
enum class CompatState { UNTESTED, RAN_OK, FAILED }
enum class RuntimeState { NOT_CONFIGURED, NOT_INSTALLED, PARTIAL, READY }

data class AppSettings(
    val language: String = "ar",
    val theme: String = "system",
    val manifestUrl: String = "",
    val defaultResolution: String = "1280x720",
    val performance: String = "balanced",
    val allowHeadless: Boolean = false,
    val touchMouse: Boolean = true
)
