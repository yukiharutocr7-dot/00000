package com.pocketwin.core

object TextUtil {
    private val ENV_KEY = Regex("^[A-Za-z_][A-Za-z0-9_]*$")

    /** Splits a command line like: --a "b c" 'd e' f  into tokens. No shell expansion. */
    fun splitArgs(s: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var quote = 0.toChar()
        var has = false
        for (ch in s) {
            when {
                quote != 0.toChar() -> if (ch == quote) quote = 0.toChar() else cur.append(ch)
                ch == '"' || ch == '\'' -> {
                    quote = ch
                    has = true
                }
                ch.isWhitespace() -> {
                    if (has || cur.isNotEmpty()) out.add(cur.toString())
                    cur.setLength(0)
                    has = false
                }
                else -> cur.append(ch)
            }
        }
        if (has || cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    /** Parses KEY=VALUE lines. Ignores blanks, comments (#) and invalid keys. */
    fun parseEnv(text: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val i = line.indexOf('=')
            if (i <= 0) continue
            val k = line.substring(0, i).trim()
            if (!ENV_KEY.matches(k)) continue
            out[k] = line.substring(i + 1).trim()
        }
        return out
    }

    /** Keeps Unicode (Arabic) names, only removes characters that cannot exist in a Linux file name. */
    fun sanitizeName(n: String): String {
        val s = n.replace('/', '_').replace(0.toChar(), '_').trim()
        return if (s.isEmpty() || s == "." || s == "..") "file" else s
    }

    fun windowsPathForUnix(path: String): String = "Z:" + path.replace('/', '\\')
}
