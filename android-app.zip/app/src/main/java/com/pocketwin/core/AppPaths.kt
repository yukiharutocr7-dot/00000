package com.pocketwin.core

import android.content.Context
import java.io.File

class AppPaths(context: Context) {
    val root: File = context.filesDir
    val runtime = File(root, "runtime")
    val downloads = File(root, "downloads")
    val containers = File(root, "containers")
    val programs = File(root, "programs")
    val logs = File(root, "logs")
    val tmp = File(context.cacheDir, "pw-tmp")

    fun ensure() {
        listOf(runtime, downloads, containers, programs, logs, tmp).forEach { it.mkdirs() }
    }

    fun containerDir(id: String) = File(containers, id)
    fun prefixDir(id: String) = File(containerDir(id), "prefix")
    fun containerTmp(id: String) = File(containerDir(id), "tmp")
    fun programDir(id: String) = File(programs, id)
    fun programLog(id: String) = File(logs, "program-$id.log")
}
