// PocketWin native bridge: spawns and supervises runtime processes (proot -> box64 -> wine).
// All argument strings are prepared BEFORE fork() so the child only calls async-signal-safe functions.
#include <jni.h>
#include <android/log.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <string>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

#define LOG_TAG "PocketWinNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

constexpr int kRunning = -1000;
constexpr int kLost = -1001;

std::string toStd(JNIEnv *env, jstring s) {
    if (s == nullptr) return std::string();
    const char *c = env->GetStringUTFChars(s, nullptr);
    if (c == nullptr) return std::string();
    std::string r(c);
    env->ReleaseStringUTFChars(s, c);
    return r;
}

std::vector<std::string> toVec(JNIEnv *env, jobjectArray arr) {
    std::vector<std::string> out;
    if (arr == nullptr) return out;
    jsize n = env->GetArrayLength(arr);
    for (jsize i = 0; i < n; i++) {
        jstring s = (jstring) env->GetObjectArrayElement(arr, i);
        out.push_back(toStd(env, s));
        if (s != nullptr) env->DeleteLocalRef(s);
    }
    return out;
}

}  // namespace

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_pocketwin_process_NativeBridge_nativeVersion(JNIEnv *env, jobject) {
    return env->NewStringUTF("pocketwin-native 0.1.0");
}

// Returns pid (> 0) on success, or a negative errno value on failure.
JNIEXPORT jint JNICALL
Java_com_pocketwin_process_NativeBridge_nativeSpawn(JNIEnv *env, jobject, jobjectArray jargv,
                                                    jobjectArray jenvp, jstring jcwd,
                                                    jstring jlog) {
    std::vector<std::string> argvS = toVec(env, jargv);
    std::vector<std::string> envS = toVec(env, jenvp);
    std::string cwd = toStd(env, jcwd);
    std::string log = toStd(env, jlog);
    if (argvS.empty()) return -EINVAL;

    std::vector<char *> argv;
    for (auto &s : argvS) argv.push_back(const_cast<char *>(s.c_str()));
    argv.push_back(nullptr);
    std::vector<char *> envp;
    for (auto &s : envS) envp.push_back(const_cast<char *>(s.c_str()));
    envp.push_back(nullptr);

    int logFd = log.empty() ? -1 : open(log.c_str(), O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
    int nullFd = open("/dev/null", O_RDONLY | O_CLOEXEC);

    pid_t pid = fork();
    if (pid < 0) {
        int err = errno;
        if (logFd >= 0) close(logFd);
        if (nullFd >= 0) close(nullFd);
        LOGE("fork failed: %d", err);
        return -err;
    }
    if (pid == 0) {
        setsid();
        if (!cwd.empty()) {
            if (chdir(cwd.c_str()) != 0) { /* continue in the current directory */ }
        }
        if (nullFd >= 0) dup2(nullFd, 0);
        if (logFd >= 0) {
            dup2(logFd, 1);
            dup2(logFd, 2);
        }
        for (int fd = 3; fd < 1024; fd++) close(fd);
        execve(argv[0], argv.data(), envp.data());
        _exit(127);
    }
    if (logFd >= 0) close(logFd);
    if (nullFd >= 0) close(nullFd);
    LOGI("spawned pid %d", (int) pid);
    return (jint) pid;
}

// Returns kRunning (-1000) while running, kLost (-1001) if the child is unknown,
// the exit code if it exited, or 128 + signal if it was killed by a signal.
JNIEXPORT jint JNICALL
Java_com_pocketwin_process_NativeBridge_nativePoll(JNIEnv *, jobject, jint pid) {
    int status = 0;
    pid_t r = waitpid((pid_t) pid, &status, WNOHANG);
    if (r == 0) return kRunning;
    if (r < 0) return kLost;
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return kLost;
}

// Signals the whole process group created by setsid() in the child.
JNIEXPORT jboolean JNICALL
Java_com_pocketwin_process_NativeBridge_nativeKill(JNIEnv *, jobject, jint pid, jint sig) {
    if (pid <= 1) return JNI_FALSE;
    return kill(-(pid_t) pid, sig) == 0 ? JNI_TRUE : JNI_FALSE;
}

}  // extern "C"
