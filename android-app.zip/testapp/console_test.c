/* PocketWin console test program: a real Windows x86-64 console executable.
 * Prints its arguments, working directory and a temp-file write test, then exits with code 0.
 * Works in headless mode (no display needed). */
#include <windows.h>
#include <stdio.h>

int main(int argc, char **argv) {
    char buf[MAX_PATH];
    char tmp[MAX_PATH];
    DWORD n;
    int i;
    FILE *f;

    printf("PocketWin console test\n");
    for (i = 0; i < argc; i++) printf("arg[%d]=%s\n", i, argv[i]);
    n = GetCurrentDirectoryA(MAX_PATH, buf);
    printf("cwd=%s\n", n ? buf : "?");
    n = GetTempPathA(MAX_PATH, tmp);
    if (n) {
        strcat(tmp, "pocketwin_test.txt");
        f = fopen(tmp, "w");
        if (f) {
            fputs("ok\n", f);
            fclose(f);
            printf("temp write ok: %s\n", tmp);
        } else {
            printf("temp write FAILED: %s\n", tmp);
        }
    }
    printf("DONE\n");
    fflush(stdout);
    return 0;
}
