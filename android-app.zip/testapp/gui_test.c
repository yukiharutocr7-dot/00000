/* PocketWin GUI test program: a real Win32 x86-64 executable.
 * Shows a window with text and two buttons and reacts to mouse and keyboard input.
 * Built by CI with mingw-w64 and bundled as an APK asset. */
#include <windows.h>
#include <stdio.h>
#include <string.h>

static int clicks = 0;
static char status[256] = "PocketWin test: waiting for input";

static void setStatus(HWND h, const char *text) {
    strncpy(status, text, sizeof(status) - 1);
    status[sizeof(status) - 1] = 0;
    InvalidateRect(h, NULL, TRUE);
}

static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    char buf[256];
    switch (m) {
    case WM_CREATE:
        CreateWindowA("BUTTON", "Click me", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                      20, 70, 140, 36, h, (HMENU)1, NULL, NULL);
        CreateWindowA("BUTTON", "Exit", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                      180, 70, 140, 36, h, (HMENU)2, NULL, NULL);
        return 0;
    case WM_COMMAND:
        if (LOWORD(w) == 1) {
            clicks++;
            snprintf(buf, sizeof(buf), "Button clicks: %d", clicks);
            setStatus(h, buf);
        } else if (LOWORD(w) == 2) {
            DestroyWindow(h);
        }
        SetFocus(h);
        return 0;
    case WM_LBUTTONDOWN:
        snprintf(buf, sizeof(buf), "Mouse down at %d,%d", (int)LOWORD(l), (int)HIWORD(l));
        setStatus(h, buf);
        SetFocus(h);
        return 0;
    case WM_KEYDOWN:
        snprintf(buf, sizeof(buf), "Key code: %d", (int)w);
        setStatus(h, buf);
        return 0;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(h, &ps);
        TextOutA(dc, 20, 24, status, (int)strlen(status));
        EndPaint(h, &ps);
        return 0;
    }
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcA(h, m, w, l);
}

int WINAPI WinMain(HINSTANCE hi, HINSTANCE hp, LPSTR cmd, int show) {
    WNDCLASSA wc;
    HWND hwnd;
    MSG msg;
    (void)hp;
    (void)cmd;
    memset(&wc, 0, sizeof(wc));
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hi;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = "PocketWinTestWindow";
    if (!RegisterClassA(&wc)) return 1;
    hwnd = CreateWindowA("PocketWinTestWindow", "PocketWin GUI Test",
                         WS_OVERLAPPEDWINDOW | WS_VISIBLE, 40, 40, 360, 180,
                         NULL, NULL, hi, NULL);
    if (!hwnd) return 2;
    ShowWindow(hwnd, show);
    while (GetMessageA(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }
    return 0;
}
