# Build the runtime components from your phone

1. Make sure the GitHub repository is PUBLIC.
2. Open the repository, tab Actions, workflow "Build Runtime Components", press Run workflow, keep the defaults, run.
   It takes roughly 20 to 60 minutes. It runs on GitHub's ARM64 runner (ubuntu-24.04-arm).
3. When it succeeds, open the run page. The summary shows the Manifest URL
   (https://github.com/YOUR_NAME/YOUR_REPO/releases/download/runtime-1/runtime-manifest.json).
4. In PocketWin: Components, paste that URL, press Refresh list, then Install / update all.
   Free storage needed: about 2 GB (downloads plus extraction).
5. Settings: enable "Allow headless launch", then add the bundled console test program and press Run.

What the workflow does: builds a static PRoot, builds Box64, creates an ARM64 Ubuntu root filesystem with the x86_64 libraries,
downloads a stable x86_64 Wine build, runs `wine64 --version` through Box64 on a real ARM64 machine (the job fails if that does not work),
publishes everything as a release and writes runtime-manifest.json with the real SHA-256 of every archive.

Known risks (not verified by the author):
- The static PRoot build can fail on some versions. Read the log of the step "Build static PRoot".
- If the automatic Wine lookup fails, run the workflow again and fill the wine_url input with a direct link to an x86_64 Wine .tar.xz.
- Box64 is built from main by default; the commit is recorded in the component version. Use a tag in box64_ref for repeatable builds.
- The smoke test runs on a server, not on your phone. A Snapdragon 662 can still behave differently and will be slow.
- The display path is still not implemented, so only console programs can run after installation.
- You redistribute GPL/LGPL components (PRoot, Wine) and Ubuntu packages through your release. Keep the licenses and source links available.
