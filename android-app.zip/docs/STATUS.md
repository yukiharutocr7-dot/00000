# PocketWin status (honest report)

## Authoring environment

The author had no Android SDK, NDK, Gradle or network access. No code in this repository has been compiled or executed.
The first CI run may expose compile errors that need small fixes. Do not treat anything below as verified on a device.

## Implemented (code written, unverified)

- Compose UI (Arabic default + RTL, English option, dark/light): splash, home, library, import, program details,
  containers, components, settings, program session screen.
- Room database for programs and containers; per-program settings (args, env, resolution, graphics mode, container).
- PE header parser (architecture x86 / x64 / ARM64, DLL, GUI/console, .NET) with unit tests.
- Importer using the Storage Access Framework (single file, folder with EXE/MSI picker, bundled samples). Import never runs the file.
- Trust warning before the first run of every program.
- DeviceCapabilityManager (Android version, ABIs, RAM, storage, Vulkan features reported by PackageManager, OpenGL ES version).
- Runtime component installer: HTTPS download, SHA-256 verification, safe extraction (zip, tar, tar.gz, tar.xz, raw), registry of installed versions.
- RuntimeManager, ContainerManager (create, rename, clone, reset, delete, initialize prefix with wineboot, find installed programs) and ProgramRunner.
- Native bridge (C++/JNI): fork/exec with log redirection, polling, process-group kill. Used for proot -> box64 -> wine.
- Launch plan builder (proot binds, environment, per-program environment) with unit tests.
- Touch to mouse mapper (tap = left click, long press = right click, drag = move, two fingers = scroll) with unit tests.
- GitHub Actions workflow, mingw-w64 build of two real Windows test programs, APK verification step.

## NOT implemented

- Display backend. Wine needs an X server to draw windows. No X server and no renderer exist in this project, so GUI programs
  cannot appear on screen. The launch is refused with NOT_IMPLEMENTED unless headless mode is enabled in Settings.
  Next step: integrate or write an Android X server (reference: Winlator) and implement DisplayBackend.
- Forwarding of touch/keyboard events to Wine (the mapper exists, its sink is a counter only). Virtual mouse overlay, virtual keyboard
  forwarding, external keyboard/mouse forwarding, gamepad, control profiles.
- Audio, microphone.
- Graphics driver selection and use (Turnip, Zink, VirGL, DXVK, VKD3D-Proton). The graphics mode is stored per program but not applied.
- Dependency installers (Visual C++, Mono, Gecko, DirectX, fonts).
- 32-bit (x86) programs: not claimed to work; no Box86/WoW64 verification.
- Runtime binaries: nothing is bundled. You must provide archives and a manifest.
- Lifecycle hardening (foreground service, process restore after the app is killed).
- MSI installation is wired to msiexec but untested.
- Per-file integrity re-verification of installed components (only the archive hash is verified at download).
- Gradle multi-module split.

## Engineering decisions

- exec from app storage requires targetSdk 28 (Android 10+ W^X restriction). Sideload distribution only.
- Rootless isolation via proot. This is not a security sandbox; unknown EXE files can still harm the data you give them.
- Wine and Box64 are not rebuilt in this repository. They are consumed as hash-pinned archives described by a manifest.
- Compatibility is never invented: a program is UNTESTED until it has actually exited with code 0 in this app.

## Tests

- Unit tests (PeParser, TextUtil, LaunchPlanBuilder, TouchMouseMapper): written, run only by CI.
- Instrumented tests, rendering, input, audio, real Wine launch: not run, need a real device.
