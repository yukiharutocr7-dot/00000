# PocketWin — Windows Programs, Android Experience
# PocketWin — تشغيل برامج Windows على Android

Android app (Kotlin, Jetpack Compose, Material 3, Room, JNI/C++) that is meant to run Windows x86-64 programs
on ARM64 phones through proot + Box64 + Wine, presented as an app library instead of a Windows desktop.

IMPORTANT, READ FIRST: see docs/STATUS.md. The app shell, library, containers, importer, component installer,
process supervisor and CI are written. The display path (X server / rendering of Wine windows), input forwarding,
audio and graphics drivers are NOT implemented yet, and the runtime binaries (rootfs, proot, box64, wine) are NOT
bundled. Until those exist, GUI programs cannot be shown. Nothing here has been compiled or run by the author.

## Build without a PC (GitHub Actions)

1. Create a GitHub repository and upload all files of this project (the GitHub mobile website supports uploads).
2. Open the repository, tab Actions, workflow "Android CI", press Run workflow (it also runs on every push).
3. When it finishes, open the run and download the artifact PocketWin-debug-apk (a zip containing the APK).
4. Extract the zip on the phone and open the APK to install it (allow "install unknown apps" for your browser or file manager).

The workflow also builds two real Windows test programs (testapp/gui_test.c and testapp/console_test.c) with mingw-w64
and bundles them into the APK as assets, and uploads them separately as PocketWin-windows-test-programs.

gradlew and gradle-wrapper.jar are binary files and are not part of this text export. CI uses gradle/actions/setup-gradle
with Gradle 8.7. In Android Studio on a PC you can generate the wrapper with: gradle wrapper --gradle-version 8.7

## First run

1. Open PocketWin. The splash screen checks the device and creates the working directories.
2. Open Components. Enter the HTTPS URL of a runtime manifest (format: docs/runtime-manifest.example.json) and press update.
   Every component must have a SHA-256; downloads that do not match are discarded. Only use manifests you trust.
3. When the runtime is READY (rootfs, proot, box64 and wine present), add a program: Library, Add program,
   choose the bundled "pocketwin console test" sample (works headless) or your own EXE.
4. Settings: enable "Allow headless launch" to run console programs while no display backend exists.
5. Press Run. The first run initializes the Wine prefix of the container (wineboot), which can take minutes.

## Layout contract for runtime archives

- runtime/rootfs: ARM64 Linux root filesystem containing Box64 (/usr/local/bin/box64, /usr/bin/box64 or /opt/box64/box64).
- runtime/rootfs/opt/wine/bin/wine64 (or wine): x86-64 Wine.
- runtime/proot/proot (+ optional runtime/proot/loader and loader32).
- Optional runtime/rootfs/pocketwin-env.conf with KEY=VALUE lines (for example BOX64_LD_LIBRARY_PATH) applied to every launch.

## Target device used for defaults

Qualcomm Snapdragon 662 (SM6115), ARM 64-bit, 8 cores, Adreno 610, 11 nm. Only arm64-v8a is built.
Do not expect desktop-class performance on this SoC.

## Modules

The project is a single Gradle module with one package per responsibility (core, data, device, runtime, container, program,
process, session, input, diagnostics, ui) instead of many Gradle modules, to keep CI reliable. See docs/STATUS.md.
